export function setupPwa({document=globalThis.document,window=globalThis.window,onConnection=()=>{}}={}){
  const q=id=>document.querySelector(id),nav=window.navigator;
  let worker=null,preparing=false,lastStatus=null,installPrompt=null;
  const status=(text,tone='info')=>{q('#offlineStatus').textContent=text;q('#offlineStatus').dataset.tone=tone;};
  const installed=()=>!!nav.standalone||!!window.matchMedia?.('(display-mode: standalone)').matches;
  function updateInstall(){q('#installSteps').hidden=installed();q('#installTitle').textContent=installed()?'Офлайн на этом телефоне':'Установить на телефон';q('#installAndroid').hidden=!installPrompt||installed();}
  function tellWorker(type,onProgress=()=>{}){
    return new Promise((resolve,reject)=>{
      if(!worker){reject(Error('Офлайн ещё не готов. Открой приложение в Safari с интернетом.'));return;}
      const channel=new (window.MessageChannel||MessageChannel)();let timer;
      const close=()=>{clearTimeout(timer);channel.port1.close();};
      const timeout=()=>{clearTimeout(timer);timer=setTimeout(()=>{close();reject(Error('Подготовка прервалась. Оставь приложение открытым и повтори с интернетом.'));},65000);};
      timeout();channel.port1.onmessage=event=>{const data=event.data;
        if(data.type==='progress'){timeout();onProgress(data);return;}
        close();if(data.type==='error')reject(Error(data.message));else resolve(data.status);
      };
      worker.postMessage({type},[channel.port2]);
    });
  }
  function showStatus(s){
    lastStatus=s;
    if(s.coreReady&&s.recognitionReady){q('#prepareOffline').hidden=true;status('Готово: расписание, PDF и фото работают без интернета.');}
    else if(!preparing){status(nav.onLine===false?'Открой приложение с интернетом — файлы для офлайна сохранятся автоматически.':'Сохраняем файлы для офлайна автоматически…');}
  }
  async function refresh(){if(!worker||preparing)return;try{showStatus(await tellWorker('STATUS'));}catch(e){status(e.message,'warning');}}
  async function prepare(){
    if(!worker||preparing||nav.onLine===false)return;
    preparing=true;q('#prepareOffline').hidden=true;q('#offlineProgress').hidden=false;
    try{
      try{await nav.storage?.persist?.();}catch{}
      let s=lastStatus||await tellWorker('STATUS');
      while(!s.coreReady||!s.recognitionReady){
        if(nav.onLine===false)break;
        const percent=s.totalBytes?Math.round(s.cachedBytes/s.totalBytes*100):0;
        q('#offlineProgressBar').style.width=percent+'%';
        status(`Офлайн-файлы сохраняются сами · ${percent}%`);
        s=await tellWorker('PREPARE');lastStatus=s;
      }
      if(s.coreReady&&s.recognitionReady){q('#offlineProgressBar').style.width='100%';showStatus(s);onConnection();}
      else status('Продолжим сохранение офлайн-файлов, когда появится интернет.');
    }catch(e){q('#prepareOffline').hidden=false;status(/quota|space/i.test(e.message)?'На телефоне закончилось место для офлайн-файлов.':`Офлайн ещё не готов: ${e.message}`,'warning');}
    finally{preparing=false;q('#offlineProgress').hidden=true;}
  }
  q('#prepareOffline').addEventListener('click',()=>void prepare());
  q('#installAndroid').addEventListener('click',async()=>{if(!installPrompt)return;await installPrompt.prompt();await installPrompt.userChoice;installPrompt=null;updateInstall();});
  window.addEventListener('beforeinstallprompt',event=>{event.preventDefault();installPrompt=event;updateInstall();});
  window.addEventListener('appinstalled',updateInstall);
  window.addEventListener('online',()=>{onConnection();void refresh().then(prepare);});
  window.addEventListener('offline',()=>onConnection());
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')void refresh().then(prepare);});
  q('#installPanel').addEventListener('toggle',()=>{if(q('#installPanel').open)void refresh();});
  updateInstall();
  if(!nav.serviceWorker||!window.isSecureContext){status('Для офлайн-режима открой ссылку в Safari. Установить можно через «Поделиться» → «На экран Домой».','warning');return {refresh};}
  status('Подключаем офлайн-режим…');
  nav.serviceWorker.register('/sw.js',{scope:'/',updateViaCache:'none'}).then(async registration=>{
    let timeout;const ready=await Promise.race([nav.serviceWorker.ready,new Promise((_,reject)=>{timeout=setTimeout(()=>reject(Error('Офлайн пока не включился. Обнови страницу в Safari с интернетом.')),20000);})]).finally(()=>clearTimeout(timeout));
    worker=ready.active;await refresh();void prepare();
    nav.serviceWorker.addEventListener('controllerchange',()=>{worker=registration.active||nav.serviceWorker.controller;lastStatus=null;void refresh().then(prepare);});
    const noteUpdate=()=>{if(registration.waiting)q('#updateHint').hidden=false;};noteUpdate();
    registration.addEventListener('updatefound',()=>{const next=registration.installing;next?.addEventListener('statechange',noteUpdate);});
    onConnection();
  }).catch(e=>{status(e.message?.includes('Офлайн')?e.message:'Не удалось включить офлайн. Открой ссылку в Safari с интернетом и обнови страницу.','warning');});
  return {refresh};
}
