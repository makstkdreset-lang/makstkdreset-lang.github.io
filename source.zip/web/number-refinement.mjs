// A small second pass on disputed room numbers. Never overwrite suffix letters
// with digits just because the restricted OCR vocabulary prefers a digit.
export async function refineRoomNumbers(worker,source,items,createCanvas,onProgress=()=>{},check=()=>{}){
 const targets=items.filter(t=>t.roomEvidence?.crop&&t.reviewText);
 if(!targets.length)return;
 try{
  await worker.setParameters({tessedit_pageseg_mode:'7',tessedit_char_whitelist:'0123456789эЭаАкКзЗоО'});
  for(let n=0;n<targets.length;n++){
   check();onProgress(n,targets.length);const t=targets[n],b=t.roomEvidence.crop;
   const w=Math.ceil(b.w),h=Math.ceil(b.h),pad=12,scale=3,c=createCanvas(w*scale+pad*2,h*scale+pad*2),ctx=c.getContext('2d');
   ctx.fillStyle='#fff';ctx.fillRect(0,0,c.width,c.height);ctx.drawImage(source,b.x,b.y,w,h,pad,pad,w*scale,h*scale);
   let data;try{({data}=await worker.recognize(c.toBuffer?c.toBuffer('image/png'):c));}finally{c.width=c.height=1;}
   check();const number=data.text.trim();
   if(data.confidence<60||!/^\d{2,5}[эЭаАкК]?$/.test(number))continue;
   const old=t.text.slice('Аудитория '.length);
   if(/[а-яё]$/i.test(old)&&!/[а-яё]$/i.test(number))continue;
   t.text='Аудитория '+number;
   // Two readings of the same number agree; label damage is immaterial.
   if(number===t.roomEvidence.pdf||number===t.roomEvidence.ocr)t.reviewText=undefined;
   else t.reviewText='Аудитория '+number+' (повторное чтение; исходные варианты '+t.roomEvidence.pdf+' / '+(t.roomEvidence.ocr||'не прочитан')+')';
  }
 }finally{await worker.setParameters({tessedit_pageseg_mode:'3',tessedit_char_whitelist:''});}
}
