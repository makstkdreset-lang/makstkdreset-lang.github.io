const DAY=86400000;
const months=['января','февраля','марта','апреля','мая','июня','июля','августа','сентября','октября','ноября','декабря'];
export function validDate(value){
  if(typeof value!=='string'||!/^20\d{2}-\d{2}-\d{2}$/.test(value))return false;
  const d=new Date(value+'T12:00:00Z');return Number.isFinite(+d)&&d.toISOString().slice(0,10)===value;
}
export function readCalendar(text){
  const m=/(?:^|\s)с\s+(\d{1,2})\s+([а-яё]+)\s+(20\d{2})\s*(?:г(?:ода)?\.?)?\s*\(\s*(числитель|знаменатель)\s*\)/i.exec(text);if(!m)return null;
  const month=months.indexOf(m[2].toLowerCase());if(month<0)return null;
  const anchorDate=`${m[3]}-${String(month+1).padStart(2,'0')}-${m[1].padStart(2,'0')}`;
  return validDate(anchorDate)?{anchorDate,anchorWeek:m[4].toLowerCase()==='числитель'?'num':'den'}:null;
}
// Compare calendar Mondays, not UTC elapsed hours (DST and device timezone safe).
export function currentWeek(calendar,now=new Date()){
  if(!calendar||!validDate(calendar.anchorDate)||!['num','den'].includes(calendar.anchorWeek))return null;
  const [y,m,d]=calendar.anchorDate.split('-').map(Number);
  const monday=(y,m,d)=>{const date=new Date(Date.UTC(y,m-1,d));return +date-((date.getUTCDay()+6)%7)*DAY;};
  const weeks=Math.round((monday(now.getFullYear(),now.getMonth()+1,now.getDate())-monday(y,m,d))/(7*DAY));
  return ((weeks%2)+2)%2?calendar.anchorWeek==='num'?'den':'num':calendar.anchorWeek;
}
export const localDay=now=>(now.getDay()+6)%7;
export const localDate=now=>`${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`;
