import {DAYS,validateSchedule} from './parser.mjs';
import {recognizeFile,abortable} from './recognize.mjs';
import {currentWeek,localDay,localDate} from './calendar.mjs';
import {setupPwa} from './pwa.mjs';
import {splitTeachers,teacherProfile} from './teachers.mjs';

const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const shortDays=['ПН','ВТ','СР','ЧТ','ПТ','СБ','ВС'];
const countText=n=>`${n} ${n===1?'пара':n>=2&&n<=4?'пары':'пар'}`;
export function fileSize(bytes){return bytes<1024*1024?Math.max(1,Math.round(bytes/1024))+' КБ':(bytes/1024/1024).toFixed(1)+' МБ';}
export function recognitionError(error){
  const text=String(error?.message||'');
  if(/fetch|NetworkError|Importing a module/i.test(text))return 'Не удалось загрузить модуль распознавания. Проверь интернет и нажми ещё раз.';
  if(/[а-яё]/i.test(text))return text;
  return 'Не удалось прочитать файл. Расписание не изменено. Обнови страницу и выбери файл заново. Если ошибка повторится, сообщи код PDF_READ.';
}

export function startApp({document=globalThis.document,window=globalThis.window,recognize=recognizeFile,now=()=>new Date(),scheduleTask=(fn,ms)=>setTimeout(fn,ms),cancelTask=id=>clearTimeout(id)}={}){
  const q=s=>document.querySelector(s),qa=s=>[...document.querySelectorAll(s)];
  const stateKey='moi-pary.ui.v5',scheduleKey='moi-pary.schedule.v1',preferencesKey='moi-pary.preferences.v1';let restored={},preferences={};
  // Recovery link clears data for this origin only. It never contacts a server.
  const currentUrl=window.location?.href?new URL(window.location.href):new URL('https://moi-pary.local/');
  if(currentUrl.searchParams.has('wipe')){
    try{window.localStorage?.removeItem(scheduleKey);window.localStorage?.removeItem(preferencesKey);window.sessionStorage?.removeItem(stateKey);}catch{}
    window.location.replace('/#today');
    return {ready:Promise.resolve(),loadSaved:async()=>{}};
  }
  try{restored=JSON.parse(window.sessionStorage.getItem(stateKey)||window.sessionStorage.getItem('moi-pary.ui.v4')||'{}')||{};}catch{}
  try{preferences=JSON.parse(window.localStorage?.getItem(preferencesKey)||'{}')||{};}catch{}
  let viewDate=localDate(now()),autoWeek=restored.weekMode!=='manual'||restored.viewDate!==viewDate;
  let week=restored.week==='den'?'den':'num',day=restored.viewDate===viewDate&&Number.isInteger(restored.day)&&restored.day>=0&&restored.day<7?restored.day:localDay(now());
  let tab='today';
  let studyDays=preferences.studyDays===5?5:6;
  let phase='idle',file=null,draft=null,reviewWeek='num',saved=null,busy=false,saving=false,controller=null,toastTimer,queued=null,waitingVisible=false,pwa=null,todayTimer=null;
  try{if(restored.draft)draft=validateSchedule(restored.draft);}catch{}
  try{saved=validateSchedule(JSON.parse(window.localStorage?.getItem(scheduleKey)||'null'));}catch{}
  const interrupted=['picking','selected','queued','recognizing'].includes(restored.phase);
  function persist(){try{window.sessionStorage.setItem(stateKey,JSON.stringify({week,day,tab,phase,draft,weekMode:autoWeek?'auto':'manual',viewDate}));}catch{}}
  function persistSchedule(){try{if(!window.localStorage)throw Error('Нет локального хранилища');if(saved)window.localStorage.setItem(scheduleKey,JSON.stringify(saved));}catch{throw Error('Не удалось сохранить расписание на телефоне. Проверь свободное место и настройки Safari.');}}
  function persistPreferences(){try{window.localStorage?.setItem(preferencesKey,JSON.stringify({studyDays,group:String(preferences.group||'').trim()}));}catch{}}
  function message(selector,text,tone='info'){const el=q(selector);el.textContent=text;el.dataset.tone=tone;el.hidden=!text;}
  function toast(text){q('#toast').textContent=text;q('#toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>q('#toast').classList.remove('show'),2000);}
  function showTab(next,update=true){tab=next==='settings'||next==='upload'?'settings':next==='week'?'week':'today';qa('.screen').forEach(el=>el.classList.toggle('active',el.id===tab));qa('[data-tab]').forEach(el=>{el.classList.toggle('active',el.dataset.tab===tab);el.setAttribute('aria-current',el.dataset.tab===tab?'page':'false');});if(update&&window.location.hash!=='#'+tab)try{window.history.replaceState(null,'','#'+tab);}catch{}persist();}
  const selectedAnchorWeek=()=>q('#anchorWeek').value||[...q('#anchorWeek').querySelectorAll('option')].find(option=>option.selected)?.value||'num';
  function renderCalendarSettings(setInputs=false){
    const calendar=draft?.calendar||saved?.calendar||null,actual=currentWeek(calendar,now()),today=now();
    if(setInputs){q('#anchorDate').value=calendar?.anchorDate||'';for(const option of q('#anchorWeek').querySelectorAll('option'))option.selected=option.value===(calendar?.anchorWeek||'num');}
    q('#settingsCalendarStatus').textContent=calendar?`Сегодня ${today.toLocaleDateString('ru-RU',{day:'numeric',month:'long'})}, ${DAYS[localDay(today)].toLowerCase()} · ${actual==='num'?'числитель':'знаменатель'}. Отсчёт идёт автоматически от ${calendar.anchorDate.split('-').reverse().join('.')}.`:'Укажи начальную дату отсчёта и выбери, числитель это или знаменатель. Дальше приложение посчитает всё само.';
    q('#saveCalendar').textContent=draft?'Применить дату к расписанию':'Сохранить дату';
  }
  function renderGroupSettings(){q('#savedGroup').value=draft?.group||saved?.group||preferences.group||'';}
  function variantMarkup(v,index,total){
    const teachers=splitTeachers(v.teacher);
    const buttons=teachers.map(name=>`<button type="button" class="teacher-button" data-teacher="${escape(name)}" data-subject="${escape(v.subject)}" aria-haspopup="dialog" aria-controls="teacherDialog" aria-label="Открыть карточку: ${escape(name)}"><span>${escape(name)}</span></button>`).join('');
    return `<div class="variant">${total>1?`<div class="subgroup">${index===0?'Левая колонка':index===1?'Правая колонка':'Подгруппа '+(index+1)}</div>`:''}<div class="subject">${escape(v.subject)}</div><div class="lesson-meta"><span class="meta">${escape(v.type||'Вид занятия не указан')}</span>${teachers.length?buttons:'<span class="meta">Преподаватель не указан</span>'}</div><div class="meta">${v.room?'Аудитория '+escape(v.room):'Аудитория не указана'}</div></div>`;
  }
  let teacherTrigger=null;
  function finishTeacherClose(){document.body.classList.remove('teacher-dialog-open');teacherTrigger?.focus();teacherTrigger=null;}
  function closeTeacher(){
    const dialog=q('#teacherDialog');
    if(typeof dialog.close==='function')dialog.close();else dialog.removeAttribute('open');
    finishTeacherClose();
  }
  function openTeacher(button){
    const profile=teacherProfile(button.dataset.teacher,saved?.group);
    q('#teacherName').textContent=profile.name;
    q('#teacherSubject').textContent=button.dataset.subject||'';
    q('#teacherCurator').hidden=!profile.isCurator;
    q('#teacherMissingName').hidden=profile.known;
    teacherTrigger=button;
    const dialog=q('#teacherDialog');
    if(typeof dialog.showModal==='function')dialog.showModal();else dialog.setAttribute('open','');
    document.body.classList.add('teacher-dialog-open');q('#closeTeacher').focus();
  }
  function lessonsMarkup(list){return list.map((l,i)=>{
    const previous=list[i-1],gaps=previous?(saved?.bellTimes||[]).filter(b=>b.start>=previous.end&&b.end<=l.start&&b.number>previous.number&&b.number<l.number):[];
    return gaps.map(b=>`<div class="gap">${b.number}-я пара · окно <span>${escape(b.start)}–${escape(b.end)}</span></div>`).join('')+`<article class="card"><div class="num">${l.number}</div><div><div class="time">${escape(l.start)}–${escape(l.end)}</div>${l.variants.map((v,i)=>variantMarkup(v,i,l.variants.length)).join('')}${l.issues?.length?'<p class="issue-note">Есть непроверенные поля после распознавания</p>':''}</div></article>`;
  }).join('');}
  function renderToday(){
    const date=now(),todayDay=localDay(date),isStudyDay=todayDay<studyDays,displayDate=new Date(date);
    const todayWeek=currentWeek(saved?.calendar,date);
    const todayLessons=saved&&todayWeek?saved.lessons.filter(l=>l.week===todayWeek&&l.day===todayDay):[];
    const latestEnd=todayLessons.reduce((end,lesson)=>lesson.end>end?lesson.end:end,'');
    const endTime=latestEnd?new Date(date.getFullYear(),date.getMonth(),date.getDate(),+latestEnd.slice(0,2),+latestEnd.slice(3,5)):null;
    const finished=isStudyDay&&endTime&&date>=endTime;
    if(todayTimer!==null){window.clearTimeout?.(todayTimer);todayTimer=null;}
    if(isStudyDay&&endTime&&!finished&&window.setTimeout)todayTimer=window.setTimeout(()=>renderToday(),Math.max(1,endTime-date+1000));
    if(!isStudyDay||finished){displayDate.setDate(displayDate.getDate()+1);while(localDay(displayDate)>=studyDays)displayDate.setDate(displayDate.getDate()+1);}
    const displayDay=localDay(displayDate),actual=currentWeek(saved?.calendar,displayDate);
    const list=saved&&actual?saved.lessons.filter(l=>l.week===actual&&l.day===displayDay).sort((a,b)=>a.start.localeCompare(b.start)):[];
    q('#todayCount').textContent=list.length;q('#todayTitle').textContent=`${DAYS[displayDay]} · ${displayDate.toLocaleDateString('ru-RU',{day:'numeric',month:'long'})}`;
    q('#todayGroup').textContent=saved?.group?'Группа '+saved.group:'Группа не указана';
    q('#todayWeek').textContent=actual?(actual==='num'?'Числитель · Ч':'Знаменатель · З'):'';
    q('#todayStatus').textContent=!isStudyDay?'Сегодня выходной · показываем ближайший понедельник':finished?`Пары на сегодня закончились · показываем ${displayDay===0?'понедельник':'следующий учебный день'}`:actual?'':saved?'Чтобы определить Ч/З, укажи начальную дату в настройках.':'Загрузи расписание в настройках.';
    q('#todayLessons').innerHTML=list.length?lessonsMarkup(list):!saved?'<div class="empty"><h3>Расписания пока нет</h3><p>Загрузи PDF или фото в настройках.</p><button type="button" class="action primary" id="todayGoSettings">Открыть настройки</button></div>':!actual?'<div class="empty"><h3>Нужна начальная дата</h3><p>Без неё приложение не сможет автоматически определить Ч/З.</p><button type="button" class="action primary" id="todayGoSettings">Настроить дату</button></div>':!isStudyDay||finished?'<div class="empty"><h3>Пар нет</h3><p>На показанный день занятий нет.</p></div>':'<div class="empty"><h3>Сегодня пар нет</h3><p>Для этого дня расписание пустое.</p></div>';
    q('#todayGoSettings')?.addEventListener('click',()=>showTab('settings'));
  }
  function renderWeek(){
    const lessons=saved?.lessons||[],current=lessons.filter(l=>l.week===week);
    const actual=currentWeek(saved?.calendar,now());
    q('#calendarStatus').textContent=actual?`Сегодня ${actual==='num'?'числитель':'знаменатель'}${autoWeek?'':' · открыт ручной просмотр'}`:saved?'Укажи начальную дату в настройках.':'';
    q('#weekToday').hidden=!saved;
    q('#count').textContent=current.length;q('#groupLabel').textContent=saved?.group?'Группа '+saved.group:'Группа не указана';
    qa('[data-week]').forEach(el=>{el.classList.toggle('active',el.dataset.week===week);el.setAttribute('aria-pressed',String(el.dataset.week===week));});
    if(day>=studyDays)day=0;const visibleDays=DAYS.slice(0,studyDays);q('#days').dataset.days=String(studyDays);
    q('#days').innerHTML=visibleDays.map((name,i)=>{const n=current.filter(l=>l.day===i).length;return `<button type="button" class="day ${i===day?'active':''}" data-day="${i}" aria-pressed="${i===day}" aria-label="${name}: ${countText(n)}"><span>${shortDays[i]}</span><b>${n||'—'}</b></button>`;}).join('');
    const list=current.filter(l=>l.day===day).sort((a,b)=>a.start.localeCompare(b.start));q('#dayTitle').textContent=DAYS[day];q('#dayCount').textContent=saved?countText(list.length):'';
    q('#lessons').innerHTML=list.length?lessonsMarkup(list):saved?'<div class="empty"><h3>Пар нет</h3><p>На этот день выбранной недели занятий нет.</p></div>':'<div class="empty"><h3>Расписание не загружено</h3><p>Открой «Настройки» и выбери PDF или фото — пары распределятся по дням и Ч/З.</p><button type="button" class="action primary" id="goUpload">Открыть настройки</button></div>';
    q('#goUpload')?.addEventListener('click',()=>showTab('settings'));
  }
  const option=(value,label,selected)=>`<option value="${escape(value)}" ${String(value)===String(selected)?'selected':''}>${escape(label)}</option>`;
  function inputField(label,field,value,index,variant=null,type='text',max=250){return `<label class="field">${label}<input type="${type}" data-index="${index}" ${variant!==null?`data-variant="${variant}"`:''} data-field="${field}" value="${escape(value)}" ${type==='number'?'min="1" max="12"':`maxlength="${max}"`}></label>`;}
  function renderReview(){
    q('#review').hidden=!draft;if(!draft){syncButtons();return;}
    const open=new Set(qa('.edit-card[open]').map(el=>+el.dataset.index));
    const counts={num:draft.lessons.filter(l=>l.week==='num').length,den:draft.lessons.filter(l=>l.week==='den').length};
    const issueCount=draft.lessons.filter(l=>l.issues?.length).length;
    q('#resultSummary').textContent=`${draft.sourceName||'Расписание'}\nЧ: ${countText(counts.num)} · З: ${countText(counts.den)}. Ещё не сохранено.`;
    q('#qualitySummary').textContent=`${issueCount?'Проверь отмеченные пары: '+issueCount+'.':'Автопроверка не нашла структурных ошибок.'}${draft.quality?.gridRows?' Границы таблицы прочитаны.':''}${draft.quality?.corrections?' Уточнено полей: '+draft.quality.corrections+'.':''}`;
    q('#issuesFilter').hidden=!issueCount;if(!issueCount)q('#issuesOnly').checked=false;
    q('#issuesLabel').textContent=`Только сомнительные пары (${issueCount})`;
    renderCalendarSettings(true);renderGroupSettings();
    q('#groupEdit').value=draft.group;
    q('#warnings').hidden=!draft.warnings?.length;q('#warnings').innerHTML=(draft.warnings||[]).map(w=>`<li>${escape(w)}</li>`).join('');
    qa('[data-review-week]').forEach(el=>{el.classList.toggle('active',el.dataset.reviewWeek===reviewWeek);el.setAttribute('aria-pressed',String(el.dataset.reviewWeek===reviewWeek));});
    q('#reviewList').innerHTML=DAYS.map((name,d)=>{
      const list=draft.lessons.map((l,index)=>({l,index})).filter(({l})=>l.day===d&&l.week===reviewWeek&&(!q('#issuesOnly').checked||l.issues?.length)).sort((a,b)=>a.l.start.localeCompare(b.l.start));
      if(!list.length)return '';
      return `<h3 class="review-day">${name} · ${countText(list.length)}</h3>`+list.map(({l,index})=>`<details class="edit-card ${l.issues?.length?'needs-review':''}" data-index="${index}" ${open.has(index)?'open':''}><summary><b>${l.number}-я пара · ${escape(l.start)}–${escape(l.end)}${l.issues?.length?' · проверить':''}</b>${l.variants.map((v,i)=>`<span>${l.variants.length>1?`<small>${i===0?'Левая':'Правая'} колонка · </small>`:''}${escape(v.subject)}<br><small>${escape(v.type||'Вид не указан')} · ${escape(v.teacher||'Преподаватель не указан')} · ${v.room?'ауд. '+escape(v.room):'аудитория не указана'}</small></span>`).join('')}</summary>${(l.issues||[]).map(s=>`<p class="issue-note">${escape(s)}</p>`).join('')}<div class="fields"><label class="field">День<select data-index="${index}" data-field="day">${DAYS.map((n,i)=>option(i,n,l.day)).join('')}</select></label><label class="field">Неделя<select data-index="${index}" data-field="week">${option('num','Числитель',l.week)}${option('den','Знаменатель',l.week)}</select></label>${inputField('Номер пары','number',l.number,index,null,'number')}${inputField('Начало','start',l.start,index,null,'time')}${inputField('Окончание','end',l.end,index,null,'time')}</div>${l.variants.map((v,i)=>`<fieldset class="edit-variant"><legend>${l.variants.length>1?(i===0?'Левая колонка':'Правая колонка'):'Занятие'}</legend>${inputField('Предмет','subject',v.subject,index,i,'text',300)}${inputField('Вид занятия','type',v.type,index,i,'text',50)}${inputField('Преподаватель','teacher',v.teacher,index,i)}${inputField('Аудитория','room',v.room,index,i,'text',100)}</fieldset>`).join('')}${l.issues?.length?`<button type="button" class="inline-button" data-checked="${index}">Проверил эту пару</button>`:''}<button type="button" class="delete" data-delete="${index}">Удалить эту пару из ${l.week==='num'?'Ч':'З'}</button></details>`).join('');
    }).join('')||`<p class="notice">${q('#issuesOnly').checked?'В этой неделе нет отмеченных пар. Проверь вторую неделю или выключи фильтр.':'На эту неделю пар не найдено. Проверь другой тип недели.'}</p>`;
    syncButtons();
  }
  const needsCheck=()=>draft?.lessons.some(l=>l.issues?.length);
  function syncButtons(){const pending=queued!==null||waitingVisible;q('#recognize').hidden=!file;q('#recognize').disabled=busy||saving||pending;q('#recognize').textContent=busy||pending?'Распознаём…':'Распознать ещё раз';q('#cancel').hidden=!busy&&!pending;q('#camera').disabled=busy||saving||pending;q('#gallery').disabled=busy||saving||pending;q('#save').disabled=!draft||!draft.lessons.length||(needsCheck()&&!q('#confirmed').checked)||busy||saving||pending;q('#save').textContent=saving?'Сохраняем…':saved?'Заменить расписание':'Сохранить в «Неделю»';q('#confirmation').hidden=!needsCheck();q('#confirmText').textContent='Я проверил отмеченные пары в Ч и З';}
  function dirty(){q('#confirmed').checked=false;message('#saveStatus','');persist();}
  function cancelPick(){phase=file?'selected':'idle';persist();message('#fileStatus',file?'Выбор отменён. Предыдущий файл остаётся выбранным.':'Выбор отменён. Можно выбрать файл ещё раз.');}
  function picked(event){const input=event.currentTarget;try{
    const selected=input.files?.[0];if(!selected){cancelPick();return;}
    if(!selected.size)throw Error('Файл пустой или недоступен. Сохрани его на телефон и выбери заново.');
    if(selected.size>25*1024*1024)throw Error('Файл больше 25 МБ. Выбери файл поменьше.');
    if(!/^image\//i.test(selected.type)&&selected.type!=='application/pdf'&&!/\.(pdf|jpe?g|png|webp|heic|heif|gif|bmp|tiff?)$/i.test(selected.name))throw Error('Нужна фотография или PDF.');
    // Close the native picker and paint feedback before starting any decoding.
    // The existing size guard still runs before allocating a photo canvas.
    cancelAuto();file=selected;phase='queued';q('#fileName').textContent=file.name||'Фото расписания';q('#fileHint').textContent='Файл выбран · '+fileSize(file.size);message('#fileStatus','Файл выбран. Сейчас распределим пары по дням и Ч/З…');showTab('settings');
    queued=scheduleTask(()=>{queued=null;if(document.visibilityState==='hidden'){waitingVisible=true;syncButtons();}else void doRecognize();},350);syncButtons();
  }catch(e){phase=file?'selected':'idle';persist();message('#fileStatus',e.message,'error');}finally{try{input.value='';}catch{}}}
  function cancelAuto(){if(queued!==null)cancelTask(queued);queued=null;waitingVisible=false;}
  async function doRecognize(){if(!file||busy||saving)return;cancelAuto();const input=file;controller=new AbortController();const attempt=controller;let timedOut=false;const timer=setTimeout(()=>{timedOut=true;attempt.abort();},180000);busy=true;phase='recognizing';persist();syncButtons();q('#progress').hidden=false;q('#progressBar').style.width='2%';message('#fileStatus','Подготавливаем распознавание…');
    try{const result=await abortable(recognize(input,{signal:attempt.signal,onProgress:(label,progress)=>{if(attempt.signal.aborted||controller!==attempt)return;message('#fileStatus',label);q('#progressBar').style.width=Math.max(2,Math.min(100,(progress||0)*100))+'%';}}),attempt.signal);
      if(attempt.signal.aborted)return;const selectedCalendar=q('#anchorDate').value?{anchorDate:q('#anchorDate').value,anchorWeek:selectedAnchorWeek()}:saved?.calendar||null;draft=validateSchedule({...result,group:result.group||preferences.group||saved?.group||'',calendar:result.calendar||selectedCalendar,sourceName:input.name||'Фото расписания'});reviewWeek=draft.lessons.find(l=>l.issues?.length)?.week||'num';q('#issuesOnly').checked=draft.lessons.some(l=>l.issues?.length);dirty();renderReview();message('#fileStatus',needsCheck()?'Пары распределены. Ниже отмечено, что нужно проверить.':'Готово: дни, пары и Ч/З распределены. Нажми «Сохранить» ниже.');q('#review').scrollIntoView?.({behavior:'smooth',block:'start'});toast('Пары распознаны');
    }catch(e){message('#fileStatus',timedOut?'Обработка заняла слишком много времени. Попробуй исходный PDF или открой ссылку в Safari / Chrome.':attempt.signal.aborted?'Распознавание отменено. Файл можно обработать ещё раз.':recognitionError(e),'warning');}
    finally{clearTimeout(timer);busy=false;phase='selected';controller=null;q('#progress').hidden=true;persist();syncButtons();}}
  async function loadSaved(){if(autoWeek)week=currentWeek(saved?.calendar,now())||week;renderToday();renderWeek();renderCalendarSettings(true);renderGroupSettings();syncButtons();void pwa?.refresh();}
  async function saveDraft(){if(!draft||busy||saving||queued!==null||waitingVisible||(needsCheck()&&!q('#confirmed').checked))return;
    let schedule;try{schedule=validateSchedule(draft);if(q('#confirmed').checked)schedule.lessons=schedule.lessons.map(l=>({...l,issues:[]}));}catch(e){message('#saveStatus',e.message,'error');return;}
    saving=true;syncButtons();message('#saveStatus','Сохраняем подтверждённое расписание…');const previous=saved;
    try{saved=schedule;preferences.group=saved.group||preferences.group||'';persistPreferences();persistSchedule();draft=null;q('#confirmed').checked=false;autoWeek=true;week=currentWeek(saved.calendar,now())||week;day=Math.min(localDay(now()),studyDays-1);viewDate=localDate(now());persist();renderReview();renderToday();renderWeek();renderCalendarSettings(true);renderGroupSettings();showTab('today');message('#fileStatus','Расписание сохранено.');toast('Расписание сохранено');}
    catch(e){saved=previous;message('#saveStatus',e.message||'Не удалось сохранить расписание.','error');}
    finally{saving=false;syncButtons();void pwa?.refresh();}
  }
  async function saveCalendar(){
    const calendar=q('#anchorDate').value?{anchorDate:q('#anchorDate').value,anchorWeek:selectedAnchorWeek()}:null;
    if(!calendar){message('#calendarActionStatus','Сначала выбери дату.','error');return;}
    try{
      if(draft){draft=validateSchedule({...draft,calendar});dirty();renderReview();message('#calendarActionStatus','Дата применена. Она сохранится вместе с расписанием.');toast('Дата применена');return;}
      if(!saved){message('#calendarActionStatus','Сначала загрузи расписание.','warning');return;}
      const updated=validateSchedule({...saved,calendar});const previous=saved;saved=updated;try{persistSchedule();}catch(e){saved=previous;throw e;}autoWeek=true;week=currentWeek(calendar,now())||week;day=Math.min(localDay(now()),studyDays-1);viewDate=localDate(now());renderToday();renderWeek();renderCalendarSettings(true);message('#calendarActionStatus','Дата сохранена. Сегодняшний день и Ч/З теперь выбираются автоматически.');toast('Дата сохранена');
    }catch(e){message('#calendarActionStatus',e.message||'Не удалось сохранить дату.','error');}
  }
  async function saveGroup(){
    const group=q('#savedGroup').value.trim();if(!group){message('#groupActionStatus','Укажи номер группы.','error');return;}
    preferences.group=group;persistPreferences();
    try{
      if(draft){draft=validateSchedule({...draft,group});dirty();renderReview();message('#groupActionStatus','Группа применена к расписанию.');toast('Группа сохранена');return;}
      if(saved){const updated=validateSchedule({...saved,group}),previous=saved;saved=updated;try{persistSchedule();}catch(e){saved=previous;throw e;}renderToday();renderWeek();}
      message('#groupActionStatus','Группа сохранена.');toast('Группа сохранена');
    }catch(e){message('#groupActionStatus',e.message||'Не удалось сохранить группу.','error');}
  }
  qa('[data-tab]').forEach(el=>el.addEventListener('click',()=>showTab(el.dataset.tab)));
  for(const selector of ['#todayLessons','#lessons'])q(selector).addEventListener('click',e=>{const button=e.target.closest?.('[data-teacher]');if(button)openTeacher(button);});
  q('#closeTeacher').addEventListener('click',closeTeacher);
  q('#teacherDialog').addEventListener('click',e=>{if(e.target===q('#teacherDialog'))closeTeacher();});
  q('#teacherDialog').addEventListener('cancel',e=>{e.preventDefault();closeTeacher();});
  q('#teacherDialog').addEventListener('close',finishTeacherClose);
  qa('[data-week]').forEach(el=>el.addEventListener('click',()=>{week=el.dataset.week;autoWeek=false;persist();renderWeek();}));
  q('#weekToday').addEventListener('click',()=>{autoWeek=true;day=Math.min(localDay(now()),studyDays-1);week=currentWeek(saved?.calendar,now())||week;viewDate=localDate(now());persist();renderWeek();});
  q('#days').addEventListener('click',e=>{const button=e.target.closest('[data-day]');if(button){day=+button.dataset.day;persist();renderWeek();}});
  qa('[data-review-week]').forEach(el=>el.addEventListener('click',()=>{reviewWeek=el.dataset.reviewWeek;renderReview();}));
  for(const id of ['#camera','#gallery']){q(id).addEventListener('click',()=>{phase='picking';showTab('settings');message('#fileStatus','Выбери файл в открывшемся окне.');});q(id).addEventListener('change',picked);q(id).addEventListener('cancel',cancelPick);}
  q('#recognize').addEventListener('click',doRecognize);q('#cancel').addEventListener('click',()=>{cancelAuto();if(controller)controller.abort();else{phase='selected';persist();syncButtons();message('#fileStatus','Распознавание отменено. Можно запустить ещё раз.');}});q('#save').addEventListener('click',saveDraft);q('#confirmed').addEventListener('change',syncButtons);
  q('#issuesOnly').addEventListener('change',renderReview);
  q('#saveCalendar').addEventListener('click',saveCalendar);
  q('#saveGroup').addEventListener('click',saveGroup);
  qa('[data-study-days]').forEach(el=>el.addEventListener('click',()=>{studyDays=+el.dataset.studyDays===5?5:6;persistPreferences();qa('[data-study-days]').forEach(button=>{const active=+button.dataset.studyDays===studyDays;button.classList.toggle('active',active);button.setAttribute('aria-pressed',String(active));});if(day>=studyDays)day=0;persist();renderToday();renderWeek();toast(studyDays===5?'Включена пятидневка':'Включена шестидневка');}));
  q('#groupEdit').addEventListener('input',()=>{if(draft){draft.group=q('#groupEdit').value;dirty();syncButtons();}});
  q('#reviewList').addEventListener('change',e=>{const el=e.target,index=+el.dataset.index,field=el.dataset.field;if(!draft||!field||!draft.lessons[index])return;const l=draft.lessons[index];if(el.dataset.variant!==undefined){if(['subject','type','teacher','room'].includes(field))l.variants[+el.dataset.variant][field]=el.value;}else if(['day','week','number','start','end'].includes(field))l[field]=['day','number'].includes(field)?+el.value:el.value;dirty();renderReview();});
  q('#reviewList').addEventListener('click',e=>{if(!draft)return;const checked=e.target.closest('[data-checked]');if(checked){draft.lessons[+checked.dataset.checked].issues=[];dirty();renderReview();return;}const button=e.target.closest('[data-delete]');if(!button)return;if(window.confirm('Удалить эту пару из черновика? Сохранённое расписание пока не изменится.')){draft.lessons.splice(+button.dataset.delete,1);dirty();renderReview();}});
  window.addEventListener('hashchange',()=>showTab(['#settings','#upload'].includes(window.location.hash)?'settings':window.location.hash==='#week'?'week':'today',false));window.addEventListener('pagehide',()=>{persist();cancelAuto();controller?.abort();if(todayTimer!==null)window.clearTimeout?.(todayTimer);});
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')return;if(localDate(now())!==viewDate){viewDate=localDate(now());autoWeek=true;day=Math.min(localDay(now()),studyDays-1);week=currentWeek(saved?.calendar,now())||week;persist();renderWeek();}renderToday();if(waitingVisible)void doRecognize();});
  qa('[data-study-days]').forEach(button=>{const active=+button.dataset.studyDays===studyDays;button.classList.toggle('active',active);button.setAttribute('aria-pressed',String(active));});
  renderToday();renderWeek();renderReview();renderCalendarSettings(true);renderGroupSettings();showTab(tab);
  if(interrupted)message('#fileStatus',draft?'Черновик восстановлен. Проверь его и сохрани. Для нового распознавания выбери файл заново.':'Страница перезагружалась. Раздел восстановлен, но файл нужно выбрать заново. При повторном вылете открой ссылку в Safari или Chrome.','warning');
  if(draft)message('#saveStatus','Восстановлен несохранённый черновик. Снова проверь его перед сохранением.');
  pwa=setupPwa({document,window,onConnection:()=>syncButtons()});
  const ready=loadSaved();return {ready,loadSaved,doRecognize,saveDraft,getState:()=>({week,day,tab,studyDays,phase,draft,saved,busy,file})};
}
if(typeof document!=='undefined'&&!globalThis.__MOI_PARY_TEST__)startApp();
