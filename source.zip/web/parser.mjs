import {readCalendar,validDate} from './calendar.mjs';
export const DAYS=['Понедельник','Вторник','Среда','Четверг','Пятница','Суббота','Воскресенье'];
const clean=s=>String(s||'').replace(/\s+/g,' ').trim();
const median=xs=>[...xs].sort((a,b)=>a-b)[Math.floor(xs.length/2)]||1;
const minutes=s=>{const [h,m]=s.split(':').map(Number);return h*60+m;};
const dayIndex=s=>DAYS.findIndex(d=>d.toLowerCase()===clean(s).toLowerCase()||d.toLowerCase()===[...clean(s).toLowerCase()].reverse().join(''));

export function pdfItems(content,viewport,util){
  return content.items.filter(i=>clean(i.str)).map(i=>{
    const t=util.transform(viewport.transform,i.transform),h=Math.hypot(t[2],t[3]);
    const vertical=Math.abs(t[1])>Math.abs(t[0]);
    const advance=i.width*viewport.scale;
    return {text:clean(i.str),x:vertical?t[4]-h:t[4],y:vertical?t[5]+Math.sign(t[1])*advance/2:t[5]-h/2,w:vertical?h:advance,h:vertical?advance:h,vertical};
  });
}

function lines(items,tolerance){
  const result=[];
  for(const item of [...items].sort((a,b)=>a.y-b.y||a.x-b.x)){
    let line=result.find(l=>Math.abs(l.y-item.y)<=tolerance);
    if(!line){line={y:item.y,items:[]};result.push(line);}
    line.items.push(item);
  }
  return result.map(l=>({...l,items:l.items.sort((a,b)=>a.x-b.x),text:clean(l.items.sort((a,b)=>a.x-b.x).map(i=>i.text).join(' '))}));
}

function distance(a,b){
  let row=Array.from({length:b.length+1},(_,i)=>i);
  for(let i=0;i<a.length;i++){const next=[i+1];for(let j=0;j<b.length;j++)next.push(Math.min(next[j]+1,row[j+1]+1,row[j]+(a[i]!==b[j])));row=next;}
  return row[b.length];
}
const kindPattern=()=>/\(?\s*(Лекционн[а-я]*|Практическ[а-я]*|Лабораторн[а-я]*)\s+заняти[а-я]*\s*\)?/gi;
function readVariant(items,fontHeight,method){
  const ls=lines(items,fontHeight*.42);
  const full=ls.map(l=>l.text).join('\n'),issues=[],corrections=[];
  const kinds=[...full.matchAll(kindPattern())],kind=kinds[0];
  let subject,type='',rest='';
  if(kind){subject=clean(full.slice(0,kind.index)).replace(/\($/,'').trim();type=/лекцион/i.test(kind[1])?'Лекция':/практич/i.test(kind[1])?'Практика':'Лабораторная';rest=full.slice(kind.index+kind[0].length).trim();}
  else{
    const boundary=ls.findIndex((l,i)=>i>0&&(/^[А-ЯЁ][а-яё-]+\s+[А-ЯЁ]\.\s*[А-ЯЁ]\./u.test(l.text)||/^(?:Аудитория|Ауд\.|Каб\.)/i.test(l.text)));
    subject=ls.slice(0,boundary<0?ls.length:boundary).map(l=>l.text).join(' ');rest=boundary<0?'':ls.slice(boundary).map(l=>l.text).join('\n');
    issues.push('Не прочитан вид занятия. Проверь название предмета.');
  }
  if(kinds.length>1)issues.push('В одной ячейке несколько занятий. Проверь разделение подгрупп.');
  let roomMatch=/(?:Аудитори[яа]|Ауд\.?|каб\.?)\s*[:№]?\s*([^\n]*)/i.exec(rest);
  if(!roomMatch&&method==='ocr'){
    // Only repair a room-label word followed by a room-like number. Never use
    // fuzzy subject/teacher matching: similar names may be different people.
    const fuzzy=/(?:^|\n)([а-яё]+)\s+([0-9ОоOЗз]{2,5}[а-яёa-z]?[.]?)\s*$/i.exec(rest);
    if(fuzzy&&fuzzy[1].toLowerCase().startsWith('а')&&distance(fuzzy[1].toLowerCase(),'аудитория')<=3){roomMatch={index:fuzzy.index,1:fuzzy[2]};corrections.push('Метка аудитории');}
  }
  let room=roomMatch?clean(roomMatch[1]):'';
  if(method==='ocr'&&/^[0-9ОоOЗз]{2,5}[а-яёa-z]?[.]?$/.test(room)){
    const fixed=room.replace(/[.]$/,'').replace(/^[0-9ОоOЗз]+/,s=>s.replace(/[ОоO]/g,'0').replace(/[Зз]/g,'3'));
    if(fixed!==room)corrections.push('Номер аудитории: '+room+' → '+fixed);room=fixed;
  }
  const teacher=clean(roomMatch?rest.slice(0,roomMatch.index):rest).replace(/[,;\s]+$/,'');
  if(method==='ocr'){
    subject=subject.replace(/^[а-яё]/u,s=>s.toUpperCase());
    const doubtful=items.filter(i=>i.confidence!==undefined&&i.confidence<65&&/[а-яёa-z]{3}/i.test(i.text));
    if(doubtful.length)issues.push('Нечёткий текст: '+doubtful.slice(0,3).map(i=>i.text).join(', ')+'.');
    if(!room&&/\d{2,}/.test(teacher))issues.push('В поле преподавателя попали цифры — возможно, это аудитория.');
  }
  return {variant:{subject,type,teacher,room},issues,corrections};
}

export function parsePositionedPage(items,{width,height,method='pdf-text',rules=[]}={}){
  const warnings=[];
  const horizontal=items.filter(i=>!i.vertical&&clean(i.text));
  const font=median(horizontal.filter(i=>i.h>0).map(i=>i.h));
  const weekHeader=horizontal.find(i=>/^Неделя$/i.test(i.text));
  let candidates=horizontal.filter(i=>/^[чз]$/i.test(i.text));
  // The numeric lookalikes are permitted only in the detected week column, and flagged for review.
  if(method==='ocr'&&weekHeader)candidates=horizontal.filter(i=>/^[чз34]$/i.test(i.text)&&Math.abs(i.x+i.w/2-weekHeader.x-weekHeader.w/2)<font*4);
  if(candidates.length<4)throw Error('Не нашёл отдельные строки «ч» и «з». Нужна таблица целиком с колонками времени и недели.');
  const buckets=[];
  for(const item of candidates){let bucket=buckets.find(b=>Math.abs(b.x-item.x)<font*3);if(!bucket){bucket={x:item.x,items:[]};buckets.push(bucket);}bucket.items.push(item);}
  const markers=buckets.sort((a,b)=>b.items.length-a.items.length)[0].items.sort((a,b)=>a.y-b.y);
  const column=median(markers.map(i=>i.x+i.w/2));
  const gap=median(markers.slice(1).map((i,n)=>i.y-markers[n].y));
  if(gap<font*1.5)throw Error('Строки недели распознаны неоднозначно. Попробуй исходный PDF или более чёткое фото.');
  const timePattern=/(\d{1,2})\s*[:.]\s*(\d{2})\s*[-–—−]\s*(\d{1,2})\s*[:.]\s*(\d{2})/;
  const timeLines=lines(horizontal.filter(i=>i.x+i.w/2<column-font&&i.y>markers[0].y-gap),font*.45);
  const times=timeLines.map(l=>{
    const m=timePattern.exec(l.text);if(!m)return null;
    const start=m[1].padStart(2,'0')+':'+m[2],end=m[3].padStart(2,'0')+':'+m[4];
    if(+m[1]>23||+m[3]>23||+m[2]>59||+m[4]>59||minutes(end)<=minutes(start))return null;
    const textItem=l.items.find(i=>/\d\s*[:.]/.test(i.text))||l.items[0];
    return {y:l.y,x:textItem.x+textItem.w/2,start,end};
  }).filter(Boolean).sort((a,b)=>a.y-b.y);
  if(!times.length)throw Error('Не удалось прочитать время пар. Проверь, что левая часть таблицы видна полностью.');
  const span=(x,y)=>{const rs=rules.filter(r=>r.axis==='h'&&r.start<=x&&r.end>column+font*3);return {top:Math.max(...rs.filter(r=>r.p<y).map(r=>r.p)),bottom:Math.min(...rs.filter(r=>r.p>y).map(r=>r.p))};};
  for(const time of times)time.bounds=span(time.x,time.y);
  const timeForMarker=new Map(markers.map(marker=>{
    const enclosed=times.filter(t=>Number.isFinite(t.bounds.top)&&Number.isFinite(t.bounds.bottom)&&marker.y>t.bounds.top&&marker.y<t.bounds.bottom);
    return [marker,enclosed.length===1?enclosed[0]:[...times].sort((a,b)=>Math.abs(a.y-marker.y)-Math.abs(b.y-marker.y))[0]];
  }));
  for(const time of times){
    const pair=markers.filter(marker=>timeForMarker.get(marker)===time);
    if(pair.length!==2||!['ч','4'].includes(pair[0].text.toLowerCase())||!['з','3'].includes(pair[1].text.toLowerCase()))throw Error('Не все метки Ч/З прочитаны однозначно. Выбери исходный PDF или более чёткое фото таблицы целиком — неполный результат не сохранён.');
  }
  const labels=items.map(i=>({...i,day:dayIndex(i.text)})).filter(i=>i.day>=0);
  const daySpans=labels.map(label=>({...label,...span(label.x,label.y)})).filter(s=>Number.isFinite(s.top)&&Number.isFinite(s.bottom));
  const blocks=[];
  for(const time of times){
    const enclosing=daySpans.filter(d=>time.y>d.top&&time.y<d.bottom);
    const detectedDay=enclosing.length===1?enclosing[0].day:null;
    let block=blocks.at(-1);
    if(!block||detectedDay!==null&&detectedDay!==block.detectedDay||minutes(time.start)<=minutes(block.times.at(-1).start)){block={times:[],detectedDay};blocks.push(block);}block.times.push(time);
  }
  for(let bi=0;bi<blocks.length;bi++){
    const block=blocks[bi];
    const top=block.times[0].y-gap,bottom=block.times.at(-1).y+gap;
    const matches=labels.filter(d=>d.y>=top&&d.y<=bottom);
    const label=block.detectedDay!==null?labels.find(l=>l.day===block.detectedDay):matches.length===1?matches[0]:null;
    block.day=label?.day??bi;block.inferredDay=!label;
    if(!label)warnings.push('День '+(bi+1)+': название не прочитано; назначен '+(DAYS[bi]||'неизвестный день')+'. Проверь.');
    if(block.day>6)throw Error('В документе найдено больше семи дней. Загрузи расписание только своей группы.');
    block.times.forEach(t=>{t.day=block.day;t.inferredDay=block.inferredDay;});
  }
  const slots=[...new Set(times.map(t=>t.start))].sort((a,b)=>minutes(a)-minutes(b));
  const lessons=[];let emptyRows=0,gridRows=0,correctionCount=0;
  const rowRules=rules.filter(r=>r.axis==='h'&&r.start<=column&&r.end>column+font*5).sort((a,b)=>a.p-b.p);
  for(let i=0;i<markers.length;i++){
    const marker=markers[i];
    let top=i?(markers[i-1].y+marker.y)/2:marker.y-gap/2;
    let bottom=i+1<markers.length?(markers[i+1].y+marker.y)/2:marker.y+gap/2;
    const above=rowRules.filter(r=>r.p<marker.y-font*.4).at(-1),below=rowRules.find(r=>r.p>marker.y+font*.4);
    const bounded=above&&below&&below.p-above.p<gap*3&&(!markers[i-1]||above.p>markers[i-1].y)&&(!markers[i+1]||below.p<markers[i+1].y);
    if(bounded){top=above.p;bottom=below.p;gridRows++;}
    const row=horizontal.filter(t=>t.x>column+font*2&&t.y>=top&&t.y<bottom);
    if(!row.length){emptyRows++;continue;}
    const time=timeForMarker.get(marker);
    if(!(marker.y>time.bounds.top&&marker.y<time.bounds.bottom&&Number.isFinite(time.bounds.top)&&Number.isFinite(time.bounds.bottom))&&Math.abs(time.y-marker.y)>gap*1.2)throw Error('Не удалось сопоставить строку с временем пары. Проверь таблицу перед повторной загрузкой.');
    const mark=marker.text.toLowerCase();
    const week=mark==='ч'||mark==='4'?'num':'den';
    if(/[34]/.test(mark))warnings.push('Метка «'+mark+'» прочитана как '+(week==='num'?'числитель':'знаменатель')+'. Проверь строку.');
    const left=Math.min(...row.map(t=>t.x)),right=Math.max(...row.map(t=>t.x+t.w));
    const divider=rules.find(r=>r.axis==='v'&&r.p>left+font*2&&r.p<right-font*2&&r.start<=top+font&&r.end>=bottom-font&&!row.some(t=>t.x<r.p-font*.3&&t.x+t.w>r.p+font*.3));
    let split=divider?.p??null;
    if(split===null){
      // Wrapped subject headings need not contain a lesson type on their FIRST
      // line. Find an actual gutter that separates two complete type labels.
      for(const line of lines(row,font*.45)){
        for(let j=1;j<line.items.length;j++){
          const prev=line.items[j-1],next=line.items[j];if(next.x-prev.x-prev.w<font*2)continue;
          const candidate=(prev.x+prev.w+next.x)/2;
          if(row.some(t=>t.x<candidate-font*.3&&t.x+t.w>candidate+font*.3))continue;
          const parts=[row.filter(t=>t.x+t.w/2<candidate),row.filter(t=>t.x+t.w/2>=candidate)];
          if(parts.every(part=>kindPattern().test(lines(part,font*.45).map(l=>l.text).join(' ')))){split=candidate;break;}
        }
        if(split!==null)break;
      }
    }
    const reads=(split!==null?[row.filter(t=>t.x+t.w/2<split),row.filter(t=>t.x+t.w/2>=split)]:[row]).map(part=>readVariant(part,font,method));
    const variants=reads.map(r=>r.variant),issues=[...new Set(reads.flatMap(r=>r.issues))];correctionCount+=reads.reduce((n,r)=>n+r.corrections.length,0);
    if(time.inferredDay)issues.push('Название дня не прочитано. Проверь день недели.');
    if(/[34]/.test(mark))issues.push('Проверь метку Ч/З: в оригинале распознана цифра '+mark+'.');
    if(row.some(t=>t.y-t.h/2<top-font*.25||t.y+t.h/2>bottom+font*.25))issues.push('Текст касается границы строки. Проверь, не попала ли соседняя пара.');
    if(variants.some(v=>!v.subject))throw Error('Предмет в одной из строк не прочитан. Нужен более чёткий файл.');
    if(variants.some(v=>!v.type))warnings.push(DAYS[time.day]+', '+time.start+': вид занятия не прочитан. Проверь текст.');
    lessons.push({id:`${time.day}-${week}-${time.start}`,day:time.day,week,number:slots.indexOf(time.start)+1,start:time.start,end:time.end,variants,issues});
  }
  const groupHeader=horizontal.find(i=>/^Группа$/i.test(i.text));
  const group=groupHeader?horizontal.find(i=>i.x>groupHeader.x+groupHeader.w&&Math.abs(i.y-groupHeader.y)<font&&/^\d[\wА-Яа-я-]{1,20}$/.test(i.text))?.text||'':'';
  if(!lessons.length)throw Error('Не найдено ни одной пары. Файл не заменил сохранённое расписание.');
  if(method==='ocr')warnings.unshift('На фото возможны ошибки даже без отметки. Сомнительные строки выделены отдельно.');
  const counts={num:lessons.filter(l=>l.week==='num').length,den:lessons.filter(l=>l.week==='den').length};
  const calendar=readCalendar(lines(horizontal.filter(i=>i.y<markers[0].y-gap/2),font*.45).map(l=>l.text).join(' '));
  return {schemaVersion:1,group,method,lessons,warnings:[...new Set(warnings)],counts,emptyRows,sourceName:'',calendar,quality:{gridRows,rows:markers.length,corrections:correctionCount},bellTimes:slots.map((start,i)=>({number:i+1,start,end:times.find(t=>t.start===start).end}))};
}

export function validateSchedule(input){
  if(!input||input.schemaVersion!==1||!Array.isArray(input.lessons)||input.lessons.length<1||input.lessons.length>200)throw Error('Некорректное расписание.');
  const string=(value,max=250)=>{if(typeof value!=='string'||value.length>max)throw Error('Некорректный текст.');return value.trim();};
  const keys=new Set();
  const lessons=input.lessons.map((l,i)=>{
    if(!Number.isInteger(l.day)||l.day<0||l.day>6||!['num','den'].includes(l.week)||!Number.isInteger(l.number)||l.number<1||l.number>12)throw Error('Проверь день и номер пары.');
    if(!/^([01]\d|2[0-3]):[0-5]\d$/.test(l.start)||!/^([01]\d|2[0-3]):[0-5]\d$/.test(l.end)||minutes(l.end)<=minutes(l.start))throw Error('Проверь время пары.');
    const key=`${l.day}-${l.week}-${l.start}`;
    if(keys.has(key))throw Error('Две пары начинаются в одно время. Объедини подгруппы или исправь время.');keys.add(key);
    if(!Array.isArray(l.variants)||!l.variants.length||l.variants.length>4)throw Error('Некорректные подгруппы.');
    const variants=l.variants.map(v=>{const subject=string(v.subject,300);if(!subject)throw Error('Укажи предмет.');return {subject,type:string(v.type||'',50),teacher:string(v.teacher||''),room:string(v.room||'',100)};});
    const issues=(Array.isArray(l.issues)?l.issues:[]).slice(0,8).map(s=>string(s,500));
    return {id:key,day:l.day,week:l.week,number:l.number,start:l.start,end:l.end,variants,issues};
  });
  for(const lesson of lessons){
    if(lessons.some(other=>other!==lesson&&other.day===lesson.day&&other.week===lesson.week&&minutes(other.start)<minutes(lesson.end)&&minutes(other.end)>minutes(lesson.start)))throw Error('Время двух пар пересекается. Проверь начало и окончание занятий.');
    if(lessons.some(other=>other!==lesson&&other.day===lesson.day&&other.week===lesson.week&&other.number===lesson.number))throw Error('У двух пар одинаковый номер. Проверь нумерацию.');
  }
  let calendar=null;
  if(input.calendar){if(!validDate(input.calendar.anchorDate)||!['num','den'].includes(input.calendar.anchorWeek))throw Error('Проверь дату и тип начальной недели.');calendar={anchorDate:input.calendar.anchorDate,anchorWeek:input.calendar.anchorWeek};}
  const quality={};for(const key of ['gridRows','rows','corrections'])quality[key]=Number.isInteger(input.quality?.[key])&&input.quality[key]>=0&&input.quality[key]<=5000?input.quality[key]:0;
  const bellSource=Array.isArray(input.bellTimes)?input.bellTimes:lessons;
  const bellTimes=[...new Map(bellSource.map(l=>[l.start,l])).values()].sort((a,b)=>String(a.start).localeCompare(String(b.start))).slice(0,12).map(l=>{
    if(!Number.isInteger(l.number)||l.number<1||l.number>12||!/^([01]\d|2[0-3]):[0-5]\d$/.test(l.start)||!/^([01]\d|2[0-3]):[0-5]\d$/.test(l.end)||minutes(l.end)<=minutes(l.start))throw Error('Проверь сетку времени пар.');
    return {number:l.number,start:l.start,end:l.end};
  });
  return {schemaVersion:1,group:string(input.group||'',60),sourceName:string(input.sourceName||''),method:['pdf-text','ocr'].includes(input.method)?input.method:'pdf-text',lessons,warnings:(Array.isArray(input.warnings)?input.warnings:[]).slice(0,50).map(w=>string(w,500)),counts:{num:lessons.filter(l=>l.week==='num').length,den:lessons.filter(l=>l.week==='den').length},calendar,quality,bellTimes};
}
