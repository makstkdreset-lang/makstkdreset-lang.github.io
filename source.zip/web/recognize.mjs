import {pdfItems,parsePositionedPage,validateSchedule} from './parser.mjs';
import {readPdfText} from './pdf-text.mjs';
import {pdfRules} from './pdf-grid.mjs';

const aborted=signal=>{if(signal?.aborted)throw new DOMException('Распознавание отменено','AbortError');};
export function abortable(promise,signal){
  if(!signal)return promise;
  return new Promise((resolve,reject)=>{
    const cancel=()=>reject(new DOMException('Распознавание отменено','AbortError'));
    signal.addEventListener('abort',cancel,{once:true});
    Promise.resolve(promise).then(value=>{signal.removeEventListener('abort',cancel);resolve(value);},error=>{signal.removeEventListener('abort',cancel);reject(error);});
    if(signal.aborted){signal.removeEventListener('abort',cancel);cancel();}
  });
}
export function ocrItems(data){return (data.blocks||[]).flatMap(b=>b.paragraphs||[]).flatMap(p=>p.lines||[]).flatMap(l=>l.words||[]).filter(w=>w.text.trim()).map(w=>({text:w.text,x:w.bbox.x0,y:(w.bbox.y0+w.bbox.y1)/2,w:w.bbox.x1-w.bbox.x0,h:w.bbox.y1-w.bbox.y0,vertical:false,confidence:w.confidence}));}

export async function refineWeekColumn(worker,source,items,width,height,createCanvas=(w,h)=>{const c=document.createElement('canvas');c.width=w;c.height=h;return c;}){
  const header=items.find(i=>/^Неделя$/i.test(i.text));if(!header)return items;
  const font=[...items].map(i=>i.h).filter(h=>h>0).sort((a,b)=>a-b)[Math.floor(items.length/2)]||header.h;
  const center=header.x+header.w/2,left=Math.max(0,Math.floor(center-font*2.2)),top=Math.ceil(header.y+header.h/2+font*.4);
  const rectangle={left,top,width:Math.min(width-left,Math.ceil(font*4.4)),height:height-top};
  if(rectangle.width<8||rectangle.height<font*4)return items;
  const scale=3,crop=createCanvas(rectangle.width*scale,rectangle.height*scale);
  const context=crop.getContext('2d');context.fillStyle='#fff';context.fillRect(0,0,crop.width,crop.height);context.drawImage(source,left,top,rectangle.width,rectangle.height,0,0,crop.width,crop.height);
  try{
    await worker.setParameters({tessedit_pageseg_mode:'6',tessedit_char_whitelist:'чзЧЗ3'});
    const {data}=await worker.recognize(crop.toBuffer?crop.toBuffer('image/png'):crop,{}, {blocks:true,text:true});
    const marks=ocrItems(data).filter(i=>/^[чз3]$/i.test(i.text)).map(i=>({...i,x:i.x/scale+left,y:i.y/scale+top,w:i.w/scale,h:i.h/scale}));
    return [...items.filter(i=>!(i.x+i.w/2>=left&&i.x+i.w/2<left+rectangle.width&&i.y>=top)),...marks];
  }finally{crop.width=crop.height=1;await worker.setParameters({tessedit_pageseg_mode:'3',tessedit_char_whitelist:''});}
}

// Remove long, straight table rules, not letter strokes. Keeps original coordinates.
export function removeGrid(image,rules=[]){
  const {width:w,height:h,data}=image,ink=new Uint8Array(w*h);
  for(let i=0;i<ink.length;i++)ink[i]=data[i*4]+data[i*4+1]+data[i*4+2]<540?1:0;
  const erase=(x,y)=>{if(x<0||y<0||x>=w||y>=h)return;const i=(y*w+x)*4;data[i]=data[i+1]=data[i+2]=data[i+3]=255;};
  for(let y=0;y<h;y++){let start=-1;for(let x=0;x<=w;x++){if(x<w&&ink[y*w+x]){if(start<0)start=x;}else if(start>=0){if(x-start>w*.18){rules.push({axis:'h',p:y,start,end:x});for(let p=start;p<x;p++)for(let d=-1;d<=1;d++)erase(p,y+d);}start=-1;}}}
  for(let x=0;x<w;x++){let start=-1;for(let y=0;y<=h;y++){if(y<h&&ink[y*w+x]){if(start<0)start=y;}else if(start>=0){if(y-start>h*.01){rules.push({axis:'v',p:x,start,end:y});if(y-start>h*.1)for(let p=start;p<y;p++)for(let d=-1;d<=1;d++)erase(x+d,p);}start=-1;}}}
  return image;
}

export async function imageDimensions(file){
  const v=new DataView(await file.slice(0,131072).arrayBuffer());
  if(v.byteLength>=24&&v.getUint32(0)===0x89504e47&&v.getUint32(4)===0x0d0a1a0a)return [v.getUint32(16),v.getUint32(20)];
  if(v.byteLength>=30&&v.getUint32(0)===0x52494646&&v.getUint32(8)===0x57454250){
    const type=v.getUint32(12);if(type===0x56503858)return [1+v.getUint8(24)+(v.getUint8(25)<<8)+(v.getUint8(26)<<16),1+v.getUint8(27)+(v.getUint8(28)<<8)+(v.getUint8(29)<<16)];
    if(type===0x56503820&&v.getUint8(23)===0x9d&&v.getUint8(24)===1&&v.getUint8(25)===0x2a)return [v.getUint16(26,true)&0x3fff,v.getUint16(28,true)&0x3fff];
    if(type===0x5650384c&&v.getUint8(20)===0x2f){const bits=v.getUint32(21,true);return [(bits&0x3fff)+1,((bits>>>14)&0x3fff)+1];}
  }
  if(v.byteLength<4||v.getUint16(0)!==0xffd8)return null;
  let offset=2;
  while(offset+4<=v.byteLength){if(v.getUint8(offset)!==0xff)return null;while(offset<v.byteLength&&v.getUint8(offset)===0xff)offset++;if(offset+3>v.byteLength)return null;const marker=v.getUint8(offset++);if(marker===0xda||marker===0xd9)return null;if(marker===1||(marker>=0xd0&&marker<=0xd7))continue;const length=v.getUint16(offset);if(length<2||offset+length>v.byteLength)return null;if([0xc0,0xc1,0xc2,0xc3,0xc5,0xc6,0xc7,0xc9,0xca,0xcb,0xcd,0xce,0xcf].includes(marker)&&length>=8)return [v.getUint16(offset+5),v.getUint16(offset+3)];offset+=length;}
  return null;
}

async function imageCanvas(file,signal){
  const dimensions=await imageDimensions(file);aborted(signal);
  if(!dimensions)throw Error('Для распознавания фото нужен JPEG, PNG или WebP. Для HEIC сделай скриншот расписания или выбери исходный PDF.');
  if(!dimensions[0]||!dimensions[1]||dimensions[0]*dimensions[1]>16000000||Math.max(...dimensions)>10000)throw Error('Изображение слишком большое для безопасной обработки на телефоне. Выбери исходный PDF или уменьшенное фото до 16 мегапикселей.');
  let bitmap,url;
  try{
    if(typeof createImageBitmap==='function')bitmap=await createImageBitmap(file);
    else{url=URL.createObjectURL(file);bitmap=await new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>resolve(img);img.onerror=()=>reject(Error('Телефон не смог открыть это фото. Попробуй PNG, JPEG или исходный PDF.'));img.src=url;});}
    aborted(signal);const scale=Math.min(1,3200/Math.max(bitmap.width,bitmap.height));
    const canvas=document.createElement('canvas');canvas.width=Math.round(bitmap.width*scale);canvas.height=Math.round(bitmap.height*scale);const context=canvas.getContext('2d',{willReadFrequently:true});context.fillStyle='#fff';context.fillRect(0,0,canvas.width,canvas.height);context.drawImage(bitmap,0,0,canvas.width,canvas.height);return canvas;
  }finally{bitmap?.close?.();if(url)URL.revokeObjectURL(url);}
}

async function scanCanvas(canvas,{signal,onProgress}){
  aborted(signal);onProgress('Загружаем модуль распознавания фото…',.08);
  const {default:tesseract}=await import('/vendor/tesseract/tesseract.esm.min.js');const {createWorker}=tesseract;aborted(signal);
  const rules=[],context=canvas.getContext('2d',{willReadFrequently:true});context.putImageData(removeGrid(context.getImageData(0,0,canvas.width,canvas.height),rules),0,0);
  let worker;
  try{
  const creating=createWorker('rus',1,{workerPath:'/vendor/tesseract/worker.min.js',corePath:'/vendor/core/tesseract-core-lstm.wasm.js',langPath:'/vendor/lang',workerBlobURL:false,cacheMethod:'none',logger:event=>{if(!signal?.aborted)onProgress(event.status==='recognizing text'?'Читаем текст на фото…':'Подготавливаем распознавание фото…',.12+(event.progress||0)*.7);}}).then(async value=>{if(signal?.aborted){await value.terminate();aborted(signal);}return value;});
    worker=await abortable(creating,signal);
    aborted(signal);await abortable(worker.setParameters({tessedit_pageseg_mode:'3',preserve_interword_spaces:'1'}),signal);
    const {data}=await abortable(worker.recognize(canvas,{}, {blocks:true,text:true}),signal);aborted(signal);
    onProgress('Уточняем колонку Ч/З…',.9);
    const items=await abortable(refineWeekColumn(worker,canvas,ocrItems(data),canvas.width,canvas.height),signal);aborted(signal);
    return parsePositionedPage(items,{width:canvas.width,height:canvas.height,method:'ocr',rules});
  }finally{if(worker)await worker.terminate();}
}

export function mergePages(pages,sourceName=''){
  if(!pages.length)throw Error('В файле нет расписания.');
  const groups=[...new Set(pages.map(p=>p.group).filter(Boolean))];
  if(groups.length>1)throw Error('В PDF несколько разных групп. Оставь страницы только своей группы.');
  const lessons=new Map();
  for(const page of pages)for(const lesson of page.lessons){const key=`${lesson.day}-${lesson.week}-${lesson.start}`;if(lessons.has(key)){const previous=lessons.get(key);if(previous.end!==lesson.end||JSON.stringify(previous.variants)!==JSON.stringify(lesson.variants))throw Error('На разных страницах есть разные пары в одно время. Загрузи только актуальное расписание своей группы.');previous.issues=[...new Set([...(previous.issues||[]),...(lesson.issues||[])])];}else lessons.set(key,{...lesson,issues:[...(lesson.issues||[])]});}
  const calendars=[...new Map(pages.filter(p=>p.calendar).map(p=>[JSON.stringify(p.calendar),p.calendar])).values()];
  if(calendars.length>1)throw Error('На страницах разные даты начала или типы недели. Оставь только актуальное расписание.');
  // A later page may omit early pairs. Number against the complete document,
  // including empty slots, instead of restarting numbering on every page.
  const bells=[...new Map(pages.flatMap(p=>p.bellTimes||p.lessons).map(l=>[l.start,{start:l.start,end:l.end}])).values()].sort((a,b)=>a.start.localeCompare(b.start)).map((l,i)=>({...l,number:i+1}));
  const merged=[...lessons.values()].map(l=>({...l,number:bells.find(b=>b.start===l.start).number}));
  const quality=Object.fromEntries(['gridRows','rows','corrections'].map(key=>[key,pages.reduce((n,p)=>n+(p.quality?.[key]||0),0)]));
  return validateSchedule({schemaVersion:1,group:groups[0]||'',sourceName,method:pages.some(p=>p.method==='ocr')?'ocr':'pdf-text',lessons:merged,warnings:[...new Set(pages.flatMap(p=>p.warnings||[]))],calendar:calendars[0]||null,quality,bellTimes:bells});
}

export async function recognizeFile(file,{signal,onProgress=()=>{}}={}){
  aborted(signal);const isPdf=file.type==='application/pdf'||/\.pdf$/i.test(file.name||'');
  if(!isPdf){const canvas=await imageCanvas(file,signal);try{return mergePages([await scanCanvas(canvas,{signal,onProgress})],file.name);}finally{canvas.width=canvas.height=1;}}
  onProgress('Открываем PDF…',.04);const pdf=await import('/vendor/pdf/pdf.mjs');aborted(signal);
  pdf.GlobalWorkerOptions.workerSrc='/vendor/pdf/pdf.worker.mjs';
  const bytes=new Uint8Array(await file.arrayBuffer());aborted(signal);
  const task=pdf.getDocument({data:bytes,isEvalSupported:false,cMapUrl:'/vendor/pdf/cmaps/',cMapPacked:true,standardFontDataUrl:'/vendor/pdf/standard_fonts/',wasmUrl:'/vendor/pdf/wasm/'});
  const cancel=()=>task.destroy();signal?.addEventListener('abort',cancel,{once:true});
  try{
    const doc=await task.promise;if(doc.numPages>6)throw Error('В PDF больше 6 страниц. Оставь только страницы своей группы.');const pages=[];
    for(let n=1;n<=doc.numPages;n++){
      aborted(signal);onProgress(`Читаем страницу ${n} из ${doc.numPages}…`,.12+.65*(n-1)/doc.numPages);
      const page=await doc.getPage(n),viewport=page.getViewport({scale:1}),content=await readPdfText(page,{signal});aborted(signal);
      const items=pdfItems(content,viewport,pdf.Util);
      if(items.length>15){const rules=pdfRules(await page.getOperatorList(),viewport,pdf);aborted(signal);pages.push(parsePositionedPage(items,{width:viewport.width,height:viewport.height,method:'pdf-text',rules}));}
      else{
        const raster=page.getViewport({scale:Math.min(4,3200/Math.max(viewport.width,viewport.height))});
        const canvas=document.createElement('canvas');canvas.width=Math.ceil(raster.width);canvas.height=Math.ceil(raster.height);
        try{await page.render({canvasContext:canvas.getContext('2d',{willReadFrequently:true}),viewport:raster}).promise;pages.push(await scanCanvas(canvas,{signal,onProgress}));}finally{canvas.width=canvas.height=1;}
      }
      page.cleanup();
    }
    onProgress('Проверяем время и разделение Ч/З…',.98);return mergePages(pages,file.name);
  }catch(e){if(e.name==='PasswordException')throw Error('PDF защищён паролем. Выбери незапароленную копию.');if(e.name==='InvalidPDFException')throw Error('PDF повреждён или не загрузился на телефон. Сохрани файл заново.');throw e;}
  finally{signal?.removeEventListener('abort',cancel);await task.destroy();}
}
