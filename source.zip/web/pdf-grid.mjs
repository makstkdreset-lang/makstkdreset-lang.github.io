// PDF.js 6 supplies painted path bounds. Thin painted shapes are table rules;
// clipping paths and text backgrounds must never become cell borders.
export function pdfRules(list,viewport,{OPS,Util}){
  let matrix=[1,0,0,1,0,0];const stack=[],rules=[];
  const paints=new Set([OPS.stroke,OPS.closeStroke,OPS.fill,OPS.eoFill,OPS.fillStroke,OPS.eoFillStroke,OPS.closeFillStroke,OPS.closeEOFillStroke]);
  for(let i=0;i<list.fnArray.length;i++){
    const op=list.fnArray[i],args=list.argsArray[i];
    if(op===OPS.save){stack.push([...matrix]);continue;}
    if(op===OPS.restore){matrix=stack.pop()||[1,0,0,1,0,0];continue;}
    if(op===OPS.transform){matrix=Util.transform(matrix,args);continue;}
    if(op!==OPS.constructPath||!paints.has(args?.[0])||args[2]?.length!==4)continue;
    const [x1,y1,x2,y2]=args[2],t=Util.transform(viewport.transform,matrix);
    const points=[[x1,y1],[x2,y1],[x1,y2],[x2,y2]].map(([x,y])=>[t[0]*x+t[2]*y+t[4],t[1]*x+t[3]*y+t[5]]);
    const xs=points.map(p=>p[0]),ys=points.map(p=>p[1]),left=Math.min(...xs),right=Math.max(...xs),top=Math.min(...ys),bottom=Math.max(...ys);
    if(bottom-top<=2*viewport.scale&&right-left>15*viewport.scale)rules.push({axis:'h',p:(top+bottom)/2,start:left,end:right});
    else if(right-left<=2*viewport.scale&&bottom-top>8*viewport.scale)rules.push({axis:'v',p:(left+right)/2,start:top,end:bottom});
  }
  return rules;
}
