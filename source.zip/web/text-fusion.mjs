// Combine an embedded OCR layer with an independent image reading. The PDF
// often preserves letters but inserts spaces inside words. No schedule-specific
// vocabulary or teacher list is used here.
const clean=s=>s.replace(/[_|]+/g,' ').replace(/^[\s,„“”'—–.]+|[\s,„“”'—–]+$/g,'').replace(/\s+/g,' ').trim();
const compact=s=>s.replace(/\s/g,'');
const labels=['Лекционные занятия','Практические занятия','Лабораторные занятия'];
function repairLabels(s){for(const label of labels){const pattern=[...label.replace(/\s/g,'')].map(c=>c+'\\s*').join('');s=s.replace(new RegExp(pattern,'gi'),label);}return s;}

const norm=s=>compact(s).toLowerCase().replace(/ё/g,'е');
export function editDistance(a,b){let r=Array.from({length:b.length+1},(_,i)=>i);for(let i=0;i<a.length;i++){const n=[i+1];for(let j=0;j<b.length;j++)n.push(Math.min(n[j]+1,r[j+1]+1,r[j]+(a[i]!==b[j])));r=n;}return r[b.length];}
function lineGroups(items,tolerance){const out=[];for(const t of [...items].sort((a,b)=>a.y-b.y||a.x-b.x)){let l=out.find(l=>Math.abs(l.y-t.y)<tolerance);if(!l)out.push(l={y:t.y,items:[]});l.items.push(t);}return out.map(l=>({...l,text:clean(l.items.sort((a,b)=>a.x-b.x).map(i=>i.text).join(' '))})).filter(l=>/[\p{L}\p{N}]/u.test(l.text));}
// Transfer word boundaries through a minimum-edit alignment; letters remain
// those actually present in the PDF, including disagreement review metadata.
function restoreSpaces(source,reference){
 const a=compact(source),b=compact(reference),al=a.toLowerCase(),bl=b.toLowerCase();
 const m=Array.from({length:a.length+1},()=>new Uint16Array(b.length+1));for(let i=0;i<=a.length;i++)m[i][0]=i;for(let j=0;j<=b.length;j++)m[0][j]=j;
 for(let i=1;i<=a.length;i++)for(let j=1;j<=b.length;j++)m[i][j]=Math.min(m[i-1][j]+1,m[i][j-1]+1,m[i-1][j-1]+(al[i-1]!==bl[j-1]));
 const spaces=new Set();let k=0;for(const ch of reference){if(/\s/.test(ch))spaces.add(k);else k++;}
 const mapped=new Set();let i=a.length,j=b.length;while(i||j){if(spaces.has(j))mapped.add(i);if(i&&j&&m[i][j]===m[i-1][j-1]+(al[i-1]!==bl[j-1])){i--;j--;}else if(i&&m[i][j]===m[i-1][j]+1)i--;else j--;}
 return [...a].map((c,n)=>(mapped.has(n)?' ':'')+c).join('').trim();
}
export function fuseCellText(hints,ocr,bounds,font){
 const output=[];
 const references=bounds.flatMap(b=>lineGroups(ocr.filter(t=>t.y>b.top&&t.y<b.bottom&&t.x+t.w/2>b.left&&t.x+t.w/2<b.right),font*.6));
 for(const b of bounds){
  const inside=t=>t.y>b.top&&t.y<b.bottom&&t.x+t.w/2>b.left&&t.x+t.w/2<b.right;
  const hs=lineGroups(hints.filter(inside),font*.65),os=lineGroups(ocr.filter(inside),font*.6);
  if(!hs.length){output.push(...ocr.filter(inside));continue;}
  const used=new Set();
  for(const h of hs){
   const o=os.filter(o=>Math.abs(o.y-h.y)<font*.9).sort((a,b)=>editDistance(norm(h.text),norm(a.text))-editDistance(norm(h.text),norm(b.text)))[0];
   const hc=compact(h.text);let text=h.text,uncertain=false;
   const reference=references.filter(r=>norm(r.text).length>norm(h.text).length*.7&&norm(r.text).length<norm(h.text).length*1.3).sort((a,b)=>editDistance(norm(h.text),norm(a.text))-editDistance(norm(h.text),norm(b.text)))[0];
   // Fixed-format fields do not need a language dictionary to restore spaces.
   if(/^[А-ЯЁа-яё]+[А-ЯЁ]\.[А-ЯЁ][.,]?(?:,[А-ЯЁа-яё]+[А-ЯЁ]\.[А-ЯЁ][.,]?)?$/u.test(hc))text=hc.replace(/([а-яё])([А-ЯЁ])\./gu,'$1 $2.').replace(/,([А-ЯЁ])/g,', $1');
   else if(/^эиос$/i.test(hc))text='ЭИОС';
   else if(o&&editDistance(norm(h.text),norm(o.text))/Math.max(norm(h.text).length,norm(o.text).length)<.28)text=restoreSpaces(h.text,reference?.text||o.text);
   else if(o){text=restoreSpaces(h.text,reference?.text||o.text);uncertain=true;}
   else {uncertain=true;}
   text=repairLabels(text);
   if(o){used.add(o);if(norm(text)!==norm(o.text))uncertain=true;}
   const roomSource=compact(h.text).replace(/^.*?(?=Аудитория)/i,'').replace(/[_,.]/g,'');
   const roomOptions=[];
   for(let n=4;n<=Math.min(14,roomSource.length-2);n++){
     const label=roomSource.slice(0,n),number=roomSource.slice(n);
     if(/^[а-яё]+$/i.test(label)&&/^[0-9ОоOЗз]{2,5}[а-яё]?$/.test(number))roomOptions.push({number,label,n,score:editDistance(label.toLowerCase(),'аудитория')});
   }
   const room=roomOptions.sort((a,b)=>a.score-b.score||b.n-a.n)[0];
   const isRoom=room&&(room.score<=3||room.score<=8&&/^[ад]/i.test(room.label)&&hs.at(-1)===h&&hs.length>1);
   if(isRoom){
     text='Аудитория '+room.number;
     if(o){const on=/([0-9]{2,5}[а-яё]?)\s*[.,»]?$/i.exec(o.text);if(on&&on[1]!==room.number){if(!/[а-яё]/i.test(room.number)&&on[1].length===room.number.length)text='Аудитория '+on[1];uncertain=true;}}
   }
   if(uncertain&&o&&norm(text)===norm(o.text))uncertain=false;
   // Compare the meaningful field, not OCR damage to a fixed label or punctuation.
   const field=s=>norm(s).replace(/[^а-яёa-z0-9]/g,'');
   const kindless=s=>s.replace(/\(?\s*(?:Лекци[а-я\s]*|Практи[а-я\s]*|Лаб[а-я\s]*)зан[а-я\s]*\)?/gi,'');
   if(text.startsWith('Аудитория ')&&o){const number=text.slice(10).replace(/[ОоO]/g,'0').replace(/[Зз](?=[0-9ОоOЗз])/g,'3');const observed=o.text.match(/([0-9ОоOЗз]{2,5}[а-яё]?)\s*[.,»]?$/i)?.[1];if(observed&&room&&field(room.number)===field(observed))uncertain=false;else if(observed&&room)uncertain=true;}
   else if(o&&field(text)===field(o.text))uncertain=false;
   else if(/занятия/.test(text)&&references.some(r=>field(kindless(text))&&field(kindless(text))===field(kindless(r.text))))uncertain=false;
   const xs=h.items.map(i=>i.x),right=Math.max(...h.items.map(i=>i.x+i.w));
   let roomEvidence;
   if(isRoom){
     const ow=o?.items.filter(t=>/^[0-9ОоЗз]{2,5}[а-яё».,]?$/i.test(t.text)).at(-1);
     const ph=h.items.filter(t=>/[0-9ОоЗз]{2,5}[а-яё]?\s*$/i.test(t.text)).at(-1);
     const crop=ow?{x:ow.x-4,y:ow.y-ow.h/2-3,w:ow.w+8,h:ow.h+6}:ph?{x:ph.x+ph.w-font*3,y:ph.y-font*.65,w:font*3.3,h:font*1.5}:null;
     roomEvidence={pdf:room.number,ocr:ow?.text||'',crop};
   }
   output.push({text,roomEvidence,x:Math.max(b.left+1,Math.min(...xs)),y:h.y,w:Math.min(b.right-1,right)-Math.max(b.left+1,Math.min(...xs)),h:font,vertical:false,reviewText:uncertain?text:undefined});
  }
  // Don't silently discard a line absent from the embedded OCR layer.
  for(const o of os)if(!used.has(o)&&!hs.some(h=>Math.abs(h.y-o.y)<font*.9))output.push(...o.items);
 }
 return output;
}
