/**
 * PDF.js 6 getTextContent() uses ReadableStream async iteration, which is
 * missing in affected iOS WebViews. Use the reader API supported there.
 * Do not patch native prototypes or the vendored PDF.js worker.
 */
export async function readPdfText(page,{signal}={}){
  const abortError=()=>{const error=new Error('Распознавание отменено');error.name='AbortError';return error;};
  if(signal?.aborted)throw abortError();
  const reader=page.streamTextContent().getReader();
  const content={items:[],styles:Object.create(null),lang:null};
  let completed=false;
  const cancel=()=>{Promise.resolve(reader.cancel(abortError())).catch(()=>{});};
  signal?.addEventListener('abort',cancel,{once:true});
  try{
    while(true){
      if(signal?.aborted)throw abortError();
      const {value,done}=await reader.read();
      if(signal?.aborted)throw abortError();
      if(done){completed=true;break;}
      content.lang??=value.lang;
      Object.assign(content.styles,value.styles);
      content.items.push(...value.items);
    }
    return content;
  }finally{
    signal?.removeEventListener('abort',cancel);
    if(!completed)cancel();
    reader.releaseLock();
  }
}
