// Recognize only a location marker, never words in a subject or teacher name.
export function isRemoteRoom(room){
 const value=String(room||'').trim().replace(/^(?:аудитория|ауд\.)\s*/i,'').replace(/[\s.]/g,'').toUpperCase();
 return ['ЭИОС','ЭИОC','ИОС','IOS','EIOS','ДИСТАНТ','ДИСТАНЦИОННО'].includes(value);
}
export const isRemoteVariant=variant=>isRemoteRoom(variant?.room);
// A mixed slot still has an in-person group and must not end the day early.
export const isRemoteLesson=lesson=>Boolean(lesson?.variants?.length)&&lesson.variants.every(isRemoteVariant);
