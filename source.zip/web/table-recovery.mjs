import {fuseCellText} from './text-fusion.mjs';
import {parsePositionedPage,DAYS} from './parser.mjs';
const median=xs=>[...xs].sort((a,b)=>a-b)[Math.floor(xs.length/2)];
const minutes=t=>+t.split(':')[0]*60 + +t.split(':')[1];
const timeRE=/(\d{1,2}):([0-5]\d)/g;
const normalizeTime=t=>{const [h,m]=t.split(':');return +h<24?h.padStart(2,'0')+':'+m:null;};

// Conservative recovery for a regular, ruled two-row-per-pair table. It uses
// the actual page pixels and independent readable marks, not a saved schedule.
// Every inferred marker/time is kept as a review issue, never silently saved.
export async function recoverRuledTable(image,ocr,textHints=[],{readCells,refineText}={}){
  const {width,height,data}=image;
  const header=textHints.find(i=>/^Недел[яи]$/i.test(i.text))||ocr.find(i=>/^Недел[яи]$/i.test(i.text));
  if(!header)throw Error('Не удалось найти колонку Ч/З для восстановления таблицы.');
  const all=[...textHints,...ocr],cx=header.x+header.w/2;
  const marks=all.filter(i=>/^[чз3]$/i.test(i.text)&&Math.abs(i.x+i.w/2-cx)<header.h*2&&i.y>header.y);
  const unique=[];for(const m of [...marks].sort((a,b)=>a.y-b.y))if(!unique.length||m.y-unique.at(-1).y>header.h)unique.push(m);
  if(unique.length<8)throw Error('Слишком мало читаемых меток для восстановления Ч/З.');
  const gap=median(unique.slice(1).map((m,i)=>m.y-unique[i].y));
  const font=header.h,left=Math.ceil(cx+font*3);
  const right=Math.min(width-1,Math.floor(Math.max(...all.filter(i=>i.y>header.y&&i.x>left).map(i=>i.x+i.w))));
  if(right-left<width*.2||gap<font*2)throw Error('Не удалось проверить сетку таблицы.');
  const peaks=[];for(let y=Math.ceil(header.y+font*.4);y<height;y++){
    let count=0;for(let x=left;x<right;x++){const k=(y*width+x)*4;if(data[k]+data[k+1]+data[k+2]<540)count++;}
    if(count<(right-left)*.45)continue;
    const prev=peaks.at(-1);if(prev&&y-prev.last<font*1.2){prev.last=y;if(count>prev.score){prev.y=y;prev.score=count;}}
    else peaks.push({y,last:y,score:count});
  }
  const chains=[];for(const peak of peaks){let chain=chains.at(-1);if(!chain||Math.abs(peak.y-chain.at(-1)-gap)>gap*.22)chains.push(chain=[]);chain.push(peak.y);}
  const borders=chains.sort((a,b)=>b.length-a.length)[0]||[];
  if(borders.length<9||(borders.length-1)%2)throw Error('Границы Ч/З прочитаны не полностью.');
  // Refuse to drop marked rows outside the chosen grid or conflicting parity.
  if(unique.some(m=>m.y<borders[0]-font||m.y>borders.at(-1)+font))throw Error('Часть строк находится вне прочитанной сетки.');
  let agreements=0,conflicts=0;
  for(let i=0;i<borders.length-1;i++)for(const m of marks.filter(m=>m.y>borders[i]+font*.2&&m.y<borders[i+1]-font*.2)){
    const num=/^ч$/i.test(m.text);if(num===(i%2===0))agreements++;else conflicts++;
  }
  if(agreements<8||conflicts>0)throw Error('Порядок Ч/З противоречит строкам таблицы.');
  const pairs=[];
  for(let i=0;i<borders.length-1;i+=2){
    const top=borders[i],bottom=borders[i+2],mid=(top+bottom)/2;
    const rangeItems=all.filter(t=>t.x+ t.w/2<cx-font*2&&t.x>cx-font*15&&Math.abs(t.y-mid)<gap*.4);
    const choices=[];
    // Text PDF items may contain both times. OCR usually returns separate words.
    for(const t of rangeItems){const compact=t.text.replace(/(?<=\d)\s+(?=\d|:)|(?<=:)\s+(?=\d)/g,'');const found=[...compact.matchAll(timeRE)].map(m=>normalizeTime(m[0])).filter(Boolean);if(found.length===2&&minutes(found[1])>minutes(found[0]))choices.push(found);}
    const words=rangeItems.filter(t=>/^\d{1,2}:[0-5]\d$/.test(t.text)).sort((a,b)=>a.x-b.x);
    const times=[...new Set(words.map(t=>normalizeTime(t.text)).filter(Boolean))];
    if(times.length===2&&minutes(times[1])>minutes(times[0]))choices.push(times);
    const distinct=[...new Map(choices.map(c=>[c.join('-'),c])).values()];
    pairs.push({top,bottom,mid,times:distinct.length===1?distinct[0]:null,inferred:distinct.length!==1});
  }
  const frequencies=new Map();
  for(const p of pairs.filter(p=>p.times)){const key=p.times.join('-');frequencies.set(key,(frequencies.get(key)||0)+1);}
  const bells=[...new Set(pairs.filter(p=>p.times).map(p=>p.times[0]))].map(start=>{
    const options=[...frequencies].filter(([key])=>key.startsWith(start+'-')).sort((a,b)=>b[1]-a[1]);
    if(options[0][1]<2||options[1]?.[1]===options[0][1])return null;
    return options[0][0].split('-');
  }).filter(Boolean).sort((a,b)=>minutes(a[0])-minutes(b[0]));
  for(const p of pairs)if(p.times&&!bells.some(b=>b.join()===p.times.join())){p.times=null;p.inferred=true;}
  if(bells.length<2||bells.length>12)throw Error('Не удалось прочитать сетку времени.');
  for(let i=0;i<pairs.length;i++)if(!pairs[i].times){
    const before=pairs.slice(0,i).map((p,j)=>({p,j})).filter(x=>!x.p.inferred).at(-1),after=pairs.map((p,j)=>({p,j})).find(x=>x.j>i&&!x.p.inferred);
    const candidates=[];if(before)candidates.push(bells.findIndex(b=>b.join()===before.p.times.join())+i-before.j);if(after)candidates.push(bells.findIndex(b=>b.join()===after.p.times.join())-(after.j-i));
    const viable=[...new Set(candidates.filter(n=>n>=0&&n<bells.length))];
    if(viable.length!==1)throw Error('Время под печатью не удалось восстановить однозначно.');
    pairs[i].times=bells[viable[0]];
  }
  const cellBounds=[];
  for(let i=0;i<borders.length-1;i++){
    const top=borders[i],bottom=borders[i+1];let divider=null;
    for(let x=Math.ceil(left+(right-left)*.25);x<right-(right-left)*.25;x++){let n=0,total=0;for(let y=Math.ceil(top+font*.6);y<bottom-font*.6;y++){total++;const k=(y*width+x)*4;if(data[k]+data[k+1]+data[k+2]<540)n++;}if(total&&n/total>.9){divider=x;break;}}
    if(divider)cellBounds.push({left,top,right:divider,bottom},{left:divider,top,right,bottom});else cellBounds.push({left,top,right,bottom});
  }
  const body=readCells?await readCells(cellBounds):textHints.length?fuseCellText(textHints,ocr,cellBounds,font):ocr;
  if(refineText)await refineText(body);
  const synthetic=body.filter(t=>t.h>=font*.35&&t.x>cx+font*2&&t.y>borders[0]&&t.y<borders.at(-1)&&/[\p{L}\p{N}]/u.test(t.text));
  // Keep reliable original header/date text and readable day labels only.
  synthetic.push(...textHints.filter(t=>t.y<header.y-font),...all.filter(t=>DAYS.some(d=>d.toLowerCase()===t.text.toLowerCase())).filter((t,i,a)=>a.findIndex(u=>u.text.toLowerCase()===t.text.toLowerCase())===i));
  synthetic.push({...header,text:'Неделя'});
  const groupHeader=textHints.find(t=>t.text.replace(/\s/g,'').toLowerCase()==='группа');
  if(groupHeader){const numbers=textHints.filter(t=>/^\d{2,5}$/.test(t.text)&&t.x>groupHeader.x+groupHeader.w&&Math.abs(t.y-groupHeader.y)<font);if(numbers.length===1)synthetic.push({...groupHeader,text:'Группа'});}
  const rules=[];
  for(const cell of cellBounds)if(cell.left!==left)rules.push({axis:'v',p:cell.left,start:cell.top,end:cell.bottom});
  for(let i=0;i<borders.length;i++)rules.push({axis:'h',p:borders[i],start:i%2?cx-font:cx-font*14,end:right});
  const recovered=[];
  for(let i=0;i<borders.length-1;i++){
    const y=(borders[i]+borders[i+1])/2,expected=i%2?'з':'ч';
    const readable=marks.some(m=>m.y>borders[i]&&m.y<borders[i+1]&&(expected==='ч'?/^ч$/i.test(m.text):/^[з3]$/i.test(m.text)));
    recovered.push(!readable);
    synthetic.push({text:expected,x:cx-font/2,y,w:font,h:font,vertical:false});
  }
  for(const p of pairs)synthetic.push({text:p.times.join(' - '),x:cx-font*12,y:p.mid,w:font*9,h:font,vertical:false});
  const sourceRows=new Map();
  const result=parsePositionedPage(synthetic,{width,height,method:'ocr',rules,onLesson:(lesson,row)=>sourceRows.set(lesson.id,row)});
  // Only inferred structure and actual text disagreements require review.
  for(const lesson of result.lessons){
    const row=sourceRows.get(lesson.id),pair=pairs[Math.floor(row/2)];
    if(recovered[row])lesson.issues.push('Метка Ч/З закрыта или повреждена; восстановлена по соседним строкам.');
    if(pair?.inferred)lesson.issues.push('Время восстановлено по повторяющейся сетке звонков.');
  }
  result.warnings.unshift('Повреждённые метки восстановлены по сетке таблицы. Проверь отмеченные пары; расписание ещё не сохранено.');
  result.quality.corrections+=recovered.filter(Boolean).length+pairs.filter(p=>p.inferred).length;
  return result;
}
