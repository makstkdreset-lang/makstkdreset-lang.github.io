// Full names for the group 103 timetable. Kept in the client bundle so cards
// continue to work when the app is running without an internet connection.
const teachers = [
  {shortName:'Акулич О.Е.',fullName:'Акулич Ольга Евгеньевна'},
  {shortName:'Батовская Е.К.',fullName:'Батовская Екатерина Константиновна'},
  {shortName:'Витт А.М.',fullName:'Витт Анастасия Михайловна'},
  {shortName:'Гребенщикова О.А.',fullName:'Гребенщикова Ольга Александровна'},
  {shortName:'Зыбалов В.С.',fullName:'Зыбалов Владимир Степанович'},
  {shortName:'Иванова С.А.',fullName:'Иванова Светлана Александровна'},
  {shortName:'Истамгулова Р.Р.',fullName:'Истамгулова Ринета Ринатовна'},
  {shortName:'Кривошеева Е.И.',fullName:'Кривошеева Елена Ивановна',curatorGroup:'103'},
  {shortName:'Лещенко Г.П.',fullName:'Лещенко Галина Павловна'},
  {shortName:'Медведева Л.М.',fullName:'Медведева Людмила Михайловна'},
  {shortName:'Палецких Н.П.',fullName:'Палецких Надежда Петровна'},
  {shortName:'Пахомова Н.А.',fullName:'Пахомова Наталья Алексеевна'},
  {shortName:'Погуляева С.А.',fullName:'Погуляева Светлана Алексеевна'},
  {shortName:'Терпугова Т.Г.',fullName:'Терпугова Татьяна Генриховна'},
  {shortName:'Трояновская И.П.',fullName:'Трояновская Ирина Павловна'},
];
const normalize = value => String(value||'').normalize('NFKC').toLocaleLowerCase('ru-RU').replace(/ё/g,'е').replace(/[.\s]+/g,'');
const directory = new Map(teachers.flatMap(teacher=>[teacher.shortName,teacher.fullName].map(name=>[normalize(name),teacher])));
export function splitTeachers(value){return String(value||'').split(/[,;\n]+/).map(name=>name.trim()).filter(Boolean);}
export function teacherProfile(name,group){
  const teacher=directory.get(normalize(name));
  return {name:teacher?.fullName||String(name).trim(),known:!!teacher,isCurator:!!teacher?.curatorGroup&&String(group).trim()===teacher.curatorGroup};
}
