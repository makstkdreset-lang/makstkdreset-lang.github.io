// Build injects versioned paths for the complete static app and OCR bundle.
const VERSION=__OFFLINE_VERSION__;
const CORE=__OFFLINE_CORE__;
const RESOURCES=__OFFLINE_RESOURCES__;
const CACHE='moi-pary-static-'+VERSION;
const origin=self.location.origin;
const absolute=path=>new URL(path,origin).href;
const knownAssets=new Set([...CORE,...RESOURCES.map(item=>item.path)]);
let preparing=null;

async function valid(response,path){
  if(!response.ok||response.type==='opaque'||new URL(response.url||absolute(path)).origin!==origin)return false;
  const contentType=response.headers.get('Content-Type')||'';
  if(path==='/'||path==='/index.html'){
    if(!/text\/html/i.test(contentType))return false;
    return (await response.clone().text()).includes('<meta name="moi-pary-static" content="1">');
  }
  return !/text\/html/i.test(contentType);
}
async function fetchAsset(path){
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),45000);
  try{
    const response=await fetch(new Request(absolute(path),{credentials:'omit',signal:controller.signal}));
    if(!await valid(response,path))throw Error('Сервер вернул не файл приложения');
    return response;
  }finally{clearTimeout(timer);}
}
async function putResource(cache,path){
  let response;
  try{response=await fetchAsset(path);}catch(error){throw Error(`Не удалось сохранить ${path}: ${error.message||'нет связи'}`);}
  await cache.put(absolute(path),response);
}
async function offlineStatus(){
  const cache=await caches.open(CACHE);
  const coreReady=(await Promise.all(CORE.map(path=>cache.match(absolute(path))))).every(Boolean);
  const stored=await Promise.all(RESOURCES.map(item=>cache.match(absolute(item.path))));
  return {coreReady,recognitionReady:stored.every(Boolean),totalBytes:RESOURCES.reduce((n,item)=>n+item.bytes,0),cachedBytes:RESOURCES.reduce((n,item,i)=>n+(stored[i]?item.bytes:0),0)};
}
async function prepareOffline(){
  const cache=await caches.open(CACHE);
  let firstError=null,attempted=0;
  for(const path of CORE){
    if(await cache.match(absolute(path)))continue;
    try{await putResource(cache,path);}catch(error){firstError??=error;}
  }
  // Keep each message short so iOS does not suspend the worker midway.
  for(const item of RESOURCES){
    if(await cache.match(absolute(item.path)))continue;
    try{await putResource(cache,item.path);}catch(error){firstError??=error;}
    if(++attempted>=8)break;
  }
  if(firstError)throw firstError;
  return offlineStatus();
}
async function navigation(request){
  const cache=await caches.open(CACHE);
  const shell=await cache.match(absolute('/'))||await cache.match(absolute('/index.html'));
  if(shell)return shell;
  try{
    const response=await fetch(request);
    if(await valid(response,'/'))try{await cache.put(absolute('/'),response.clone());}catch{}
    return response;
  }catch{return new Response('Открой «Мои пары» с интернетом для первой загрузки.',{status:503,headers:{'Content-Type':'text/plain; charset=utf-8'}});}
}
async function assetRequest(request){
  const url=new URL(request.url),cache=await caches.open(CACHE);
  const key=knownAssets.has(url.pathname+url.search)?request.url:absolute(url.pathname);
  const cached=await cache.match(key);if(cached)return cached;
  const response=await fetch(request);
  if(await valid(response,url.pathname))try{await cache.put(key,response.clone());}catch{}
  return response;
}
self.addEventListener('install',event=>event.waitUntil((async()=>{
  const cache=await caches.open(CACHE);
  await Promise.all(CORE.map(path=>putResource(cache,path).catch(()=>{})));
  await self.skipWaiting();
})()));
self.addEventListener('activate',event=>event.waitUntil((async()=>{
  for(const key of await caches.keys())if((key.startsWith('moi-pary-static-')||key.startsWith('moi-pary-assets-'))&&key!==CACHE)await caches.delete(key);
  await self.clients.claim();
})()));
self.addEventListener('fetch',event=>{
  const {request}=event,url=new URL(request.url);
  if(url.origin!==origin||request.method!=='GET')return;
  if(request.mode==='navigate'&&['/','/index.html'].includes(url.pathname)){event.respondWith(navigation(request));return;}
  if(knownAssets.has(url.pathname+url.search)||knownAssets.has(url.pathname))event.respondWith(assetRequest(request));
});
self.addEventListener('message',event=>{
  if(event.data?.type==='SKIP_WAITING'){event.waitUntil(self.skipWaiting());return;}
  if(!event.source?.url||new URL(event.source.url).origin!==origin||!event.ports?.[0])return;
  const port=event.ports[0];
  event.waitUntil((async()=>{
    try{
      if(event.data?.type==='STATUS'){port.postMessage({type:'done',status:await offlineStatus()});return;}
      if(event.data?.type==='PREPARE'){
        if(preparing)throw Error('Подготовка уже идёт в другом окне.');
        preparing=prepareOffline();try{port.postMessage({type:'done',status:await preparing});}finally{preparing=null;}
      }
    }catch(error){port.postMessage({type:'error',message:error.message||'Не удалось подготовить офлайн.'});}
  })());
});
