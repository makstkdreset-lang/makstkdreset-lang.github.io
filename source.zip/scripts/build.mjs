import {build} from 'esbuild';
import {mkdir,cp,readdir,copyFile,writeFile,readFile,stat,rm} from 'node:fs/promises';
import {createHash} from 'node:crypto';
await mkdir('dist/client/vendor',{recursive:true});
await build({entryPoints:['web/app.mjs'],outfile:'dist/client/app.js',bundle:true,format:'esm',platform:'browser',target:'es2022',external:['/vendor/*']});
await copyFile('dist/index.html','dist/client/index.html');
await copyFile('web/manifest.webmanifest','dist/client/manifest.webmanifest');
await cp('web/icons','dist/client/icons',{recursive:true});
await copyFile('web/icon.svg','dist/client/icons/icon.svg');
await mkdir('dist/client/vendor/pdf',{recursive:true});
for(const file of ['pdf.mjs','pdf.worker.mjs'])await copyFile('node_modules/pdfjs-dist/legacy/build/'+file,'dist/client/vendor/pdf/'+file);
for(const folder of ['cmaps','standard_fonts','wasm'])await cp('node_modules/pdfjs-dist/'+folder,'dist/client/vendor/pdf/'+folder,{recursive:true});
await mkdir('dist/client/vendor/tesseract',{recursive:true});
for(const file of ['tesseract.esm.min.js','worker.min.js'])await copyFile('node_modules/tesseract.js/dist/'+file,'dist/client/vendor/tesseract/'+file);
await rm('dist/client/vendor/core',{recursive:true,force:true});
await mkdir('dist/client/vendor/core',{recursive:true});
// Keep one small, portable LSTM core.  Shipping every SIMD/non-SIMD variant
// makes the offline bundle ~52 MB and exceeds storage limits in some iOS PWAs.
// Tesseract can use this core on every supported device; the worker is pointed
// at it explicitly in recognize.mjs.
for(const file of ['tesseract-core-lstm.wasm','tesseract-core-lstm.wasm.js'])
  await copyFile('node_modules/tesseract.js-core/'+file,'dist/client/vendor/core/'+file);
await mkdir('dist/client/vendor/lang',{recursive:true});
await copyFile('node_modules/@tesseract.js-data/rus/4.0.0_best_int/rus.traineddata.gz','dist/client/vendor/lang/rus.traineddata.gz');
for(const [name,path] of [['pdf','pdfjs-dist/LICENSE'],['tesseract','tesseract.js/LICENSE.md'],['core','tesseract.js-core/LICENSE']])await copyFile('node_modules/'+path,'dist/client/vendor/'+name+'/LICENSE');
const appUrl=/src="(\/app\.js(?:\?[^\"]*)?)"/.exec(await readFile('dist/client/index.html','utf8'))?.[1];
if(!appUrl)throw Error('Offline build could not find the main application script.');
const core=['/',appUrl,'/manifest.webmanifest','/icons/icon.svg?v=1.7',...[32,180,192,512].map(size=>`/icons/icon-${size}.png?v=1.7`)];
const resources=[];
async function inventory(dir){for(const entry of await readdir(dir,{withFileTypes:true})){const path=dir+'/'+entry.name;if(entry.isDirectory())await inventory(path);else if(entry.name!=='LICENSE'){resources.push({path:path.replace('dist/client',''),bytes:(await stat(path)).size});}}}
await inventory('dist/client/vendor');resources.sort((a,b)=>a.path.localeCompare(b.path));
const sw=await readFile('web/sw.mjs','utf8'),hash=createHash('sha256');
for(const path of ['dist/client/index.html','dist/client/app.js','web/sw.mjs','web/manifest.webmanifest','web/icon.svg','web/icons/icon-180.png','web/icons/icon-192.png','web/icons/icon-512.png','package-lock.json'])hash.update(await readFile(path));
const version=hash.digest('hex').slice(0,16);
await writeFile('dist/client/sw.js',sw.replace('__OFFLINE_VERSION__',JSON.stringify(version)).replace('__OFFLINE_CORE__',JSON.stringify(core)).replace('__OFFLINE_RESOURCES__',JSON.stringify(resources)));
await writeFile('dist/client/.nojekyll','');
await writeFile('dist/client/_headers','/index.html\n  Cache-Control: no-cache\n/app.js\n  Cache-Control: no-cache\n/sw.js\n  Cache-Control: no-cache\n  Service-Worker-Allowed: /\n/manifest.webmanifest\n  Content-Type: application/manifest+json\n  Cache-Control: no-cache\n/vendor/*\n  Cache-Control: public, max-age=86400\n');
console.log('Built standalone static app and offline resource list ('+Math.ceil(resources.reduce((n,r)=>n+r.bytes,0)/1048576)+' MB). Publish dist/client/ at the root of an HTTPS static host.');
