import {test} from 'node:test';
import assert from 'node:assert/strict';
import {parsePositionedPage,validateSchedule} from '../web/parser.mjs';
import {imageDimensions,mergePages,removeGrid} from '../web/recognize.mjs';
function fixture(){
  const item=(text,x,y,w=30,h=10)=>({text,x,y,w,h,vertical:false});
  const items=[item('Неделя',170,60,40),item('Группа',100,35,40),item('103',300,35),item('Понедельник',50,150),item('Вторник',50,310)];
  for(const [i,y] of [100,140,180,220,260,300,340,380].entries())items.push(item(i%2?'з':'ч',180,y,8));
  for(const [y,time] of [[120,'08:00–09:35'],[200,'09:45–11:20'],[280,'08:00–09:35'],[360,'09:45–11:20']])items.push(item(time,110,y,55));
  for(const y of [100,140,180,260,300,340,380]){items.push(item(y===140?'Экология (Практические занятия)':'Химия (Лекционные занятия)',230,y-10,200));items.push(item('Иванов И.И.',270,y,65));items.push(item('Аудитория 101',260,y+10,90));}
  return items;
}
test('table coordinates map numerators/denominators, day boundaries and empty cells',()=>{
  const s=parsePositionedPage(fixture());assert.deepEqual(s.counts,{num:4,den:3});assert.equal(s.group,'103');assert.equal(s.emptyRows,1);assert.equal(s.lessons.find(l=>l.day===0&&l.week==='den').variants[0].subject,'Экология');assert.equal(s.lessons.find(l=>l.day===1&&l.start==='09:45').number,2);validateSchedule(s);
});
test('missing or ambiguous week marks reject incomplete recognition rather than mixing weeks',()=>{assert.throws(()=>parsePositionedPage(fixture().filter(i=>!(i.text==='з'&&i.y===140))),/Не все метки/);});
test('duplicate lesson slots, impossible times and empty subjects cannot be saved',()=>{
  const s=parsePositionedPage(fixture());assert.throws(()=>validateSchedule({...s,lessons:[...s.lessons,s.lessons[0]]}),/Две пары/);
  for(const edit of [l=>l.end='25:30',l=>l.day=7,l=>l.variants[0].subject='']){const bad=structuredClone(s);edit(bad.lessons[0]);assert.throws(()=>validateSchedule(bad));}
});
test('multi-page import deduplicates identical pages but rejects conflicting groups or lesson slots',()=>{
  const s=parsePositionedPage(fixture());assert.equal(mergePages([s,s]).lessons.length,7);
  assert.throws(()=>mergePages([s,{...s,group:'104'}]),/несколько разных групп/);
  const different=structuredClone(s);different.lessons[0].variants[0].subject='Другой предмет';assert.throws(()=>mergePages([s,different]),/разные пары/);
});
test('image header dimensions are read without full decoding and malformed headers rejected',async()=>{
  const buffer=new ArrayBuffer(24),v=new DataView(buffer);[0x89504e47,0x0d0a1a0a,13,0x49484452,4032,3024].forEach((n,i)=>v.setUint32(i*4,n));assert.deepEqual(await imageDimensions({slice:()=>({arrayBuffer:async()=>buffer})}),[4032,3024]);assert.equal(await imageDimensions({slice:()=>({arrayBuffer:async()=>new ArrayBuffer(1)})}),null);
});
test('grid removal keeps small letter strokes and clears table rules',()=>{
  const width=100,height=100,data=new Uint8ClampedArray(width*height*4).fill(255);const black=(x,y)=>{const i=(y*width+x)*4;data[i]=data[i+1]=data[i+2]=0;};for(let x=10;x<90;x++)black(x,50);for(let x=10;x<15;x++)black(x,20);removeGrid({width,height,data});assert.equal(data[(50*width+30)*4],255);assert.equal(data[(20*width+12)*4],0);
});

test('Cyrillic З and OCR digit 3 work in PDF and photo week columns, including plural header',()=>{
  for(const method of ['pdf-text','ocr'])for(const header of ['Неделя','Недели',null])for(const mark of ['з','З','3']){
    const items=fixture().filter(i=>header!==null||i.text!=='Неделя').map(i=>({...i,text:i.text==='Неделя'?header:i.text==='з'?mark:i.text}));
    // Other columns contain the same digit, but must not become week markers.
    items.push({text:'3',x:600,y:100,w:8,h:10,vertical:false});
    const result=parsePositionedPage(items,{method});
    assert.deepEqual(result.counts,{num:4,den:3});validateSchedule(result);
    assert.equal(result.lessons[1].variants[0].subject,'Экология');
    assert.ok(!result.lessons.some(l=>l.issues.some(i=>i.includes('метку Ч/З'))));
  }
});
test('Latin Z is not a week marker and digit 3 never substitutes a missing numerator',()=>{
  for(const [original,replacement] of [['з','Z'],['ч','3']])assert.throws(()=>parsePositionedPage(fixture().map(i=>({...i,text:i.text===original?replacement:i.text}))),/Не все метки/);
});

test('standalone remote location is parsed separately from the teacher',()=>{
 for(const marker of ['ЭИОС','Э И О С','IOS','Дистант']){
  const s=parsePositionedPage(fixture().map(i=>({...i,text:i.text==='Аудитория 101'?marker:i.text})));
  assert.equal(s.lessons[0].variants[0].room,marker);assert.equal(s.lessons[0].variants[0].teacher,'Иванов И.И.');
 }
});
test('remote markers are matched only as complete room values',async()=>{
 const {isRemoteRoom,isRemoteLesson}=await import('../web/lesson-mode.mjs');
 for(const room of ['ЭИОС','э и о с','IOS','Дистант','Аудитория ЭИОС'])assert.equal(isRemoteRoom(room),true);
 for(const room of ['','303','203э','IOS 101'])assert.equal(isRemoteRoom(room),false);
 assert.equal(isRemoteLesson({variants:[]}),false);
 assert.equal(isRemoteLesson({variants:[{room:'ЭИОС'},{room:'103'}]}),false);
});

test('single-week table reads ruled days, times and subjects without Ch/Z markers',()=>{
 const i=(text,x,y,w=40)=>({text,x,y,w,h:10,vertical:false});
 const items=[i('Время',100,30),i('Группа',10,10),i('201',100,10),i('Понедельник',10,100),i('Вторник',10,200)];
 const rules=[50,150,250].map(p=>({axis:'h',p,start:0,end:600}));
 for(const y of [100,200])items.push(i('08:00–09:35',100,y,80),i('Математика (Лекционные занятия)',220,y-15,250),i('Иванов И.И.',220,y),i('Аудитория 302',220,y+15,120));
 items.push(i('Неделя',450,30),i('ч',550,30));
 const s=parsePositionedPage(items,{rules,weekMode:'single'});
 assert.equal(s.weekMode,'single');assert.deepEqual(s.lessons.map(l=>[l.day,l.week,l.variants[0].room]),[[0,'num','302'],[1,'num','302']]);
 assert.equal(mergePages([s]).weekMode,'single');
 assert.throws(()=>parsePositionedPage(items,{rules}),/строки/);
 assert.throws(()=>parsePositionedPage(items.filter(i=>i.text!=='Вторник'),{rules,weekMode:'single'}),/день/);
});
