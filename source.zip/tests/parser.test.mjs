import {test} from 'node:test';
import assert from 'node:assert/strict';
import {parsePositionedPage,validateSchedule} from '../web/parser.mjs';
import {imageDimensions,mergePages,removeGrid} from '../web/recognize.mjs';
function fixture(){
  const item=(text,x,y,w=30,h=10)=>({text,x,y,w,h,vertical:false});
  const items=[item('Неделя',170,60,40),item('Группа',100,35,40),item('103',300,35),item('Понедельник',50,150),item('Вторник',50,310)];
  for(const [i,y] of [100,140,180,220,260,300,340,380].entries())items.push(item(i%2?'з':'ч',180,y,8));
  for(const [y,time] of [[120,'08:00–09:35'],[200,'09:45–11:20'],[280,'08:00–09:35'],[360,'09:45–11:20']])items.push(item(time,110,y,55));
  for(const y of [100,140,180,260,300,340,380]){items.push(item(y===140?'Экология (Практические занятия)':'Химия (Лекционные занятия)',230,y-10,200));items.push(item('Иванов И.И.',270,y,65));items.push(item('Аудитория 101',260,y+10,90));}
  return items;
}
test('table coordinates map numerators/denominators, day boundaries and empty cells',()=>{
  const s=parsePositionedPage(fixture());assert.deepEqual(s.counts,{num:4,den:3});assert.equal(s.group,'103');assert.equal(s.emptyRows,1);assert.equal(s.lessons.find(l=>l.day===0&&l.week==='den').variants[0].subject,'Экология');assert.equal(s.lessons.find(l=>l.day===1&&l.start==='09:45').number,2);validateSchedule(s);
});
test('missing or ambiguous week marks reject incomplete recognition rather than mixing weeks',()=>{assert.throws(()=>parsePositionedPage(fixture().filter(i=>!(i.text==='з'&&i.y===140))),/Не все метки/);});
test('duplicate lesson slots, impossible times and empty subjects cannot be saved',()=>{
  const s=parsePositionedPage(fixture());assert.throws(()=>validateSchedule({...s,lessons:[...s.lessons,s.lessons[0]]}),/Две пары/);
  for(const edit of [l=>l.end='25:30',l=>l.day=7,l=>l.variants[0].subject='']){const bad=structuredClone(s);edit(bad.lessons[0]);assert.throws(()=>validateSchedule(bad));}
});
test('multi-page import deduplicates identical pages but rejects conflicting groups or lesson slots',()=>{
  const s=parsePositionedPage(fixture());assert.equal(mergePages([s,s]).lessons.length,7);
  assert.throws(()=>mergePages([s,{...s,group:'104'}]),/несколько разных групп/);
  const different=structuredClone(s);different.lessons[0].variants[0].subject='Другой предмет';assert.throws(()=>mergePages([s,different]),/разные пары/);
});
test('image header dimensions are read without full decoding and malformed headers rejected',async()=>{
  const buffer=new ArrayBuffer(24),v=new DataView(buffer);[0x89504e47,0x0d0a1a0a,13,0x49484452,4032,3024].forEach((n,i)=>v.setUint32(i*4,n));assert.deepEqual(await imageDimensions({slice:()=>({arrayBuffer:async()=>buffer})}),[4032,3024]);assert.equal(await imageDimensions({slice:()=>({arrayBuffer:async()=>new ArrayBuffer(1)})}),null);
});
test('grid removal keeps small letter strokes and clears table rules',()=>{
  const width=100,height=100,data=new Uint8ClampedArray(width*height*4).fill(255);const black=(x,y)=>{const i=(y*width+x)*4;data[i]=data[i+1]=data[i+2]=0;};for(let x=10;x<90;x++)black(x,50);for(let x=10;x<15;x++)black(x,20);removeGrid({width,height,data});assert.equal(data[(50*width+30)*4],255);assert.equal(data[(20*width+12)*4],0);
});
