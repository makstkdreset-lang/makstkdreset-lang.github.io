import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {parseHTML} from 'linkedom';
import {setupPwa} from '../web/pwa.mjs';

test('opening the installed app prepares missing offline modules without a tap',async()=>{
  const {document}=parseHTML(readFileSync(new URL('../dist/index.html',import.meta.url),'utf8'));
  let batches=0;
  const worker={postMessage({type},[port]){
    if(type==='PREPARE')batches++;
    const status={coreReady:true,recognitionReady:batches>=3,cachedBytes:batches*1024,totalBytes:4096,hasSchedule:false};
    queueMicrotask(()=>port.peer.onmessage({data:{type:'done',status}}));
  }};
  const serviceWorker={ready:Promise.resolve({active:worker}),register:async()=>({active:worker,addEventListener(){}}),addEventListener(){}};
  const window={navigator:{onLine:true,standalone:true,serviceWorker},isSecureContext:true,matchMedia:()=>({matches:true}),addEventListener(){},MessageChannel:class {
    constructor(){this.port1={onmessage:null,close(){}};this.port2={peer:this.port1};}
  }};
  setupPwa({document,window});
  for(let i=0;i<20&&batches<3;i++)await new Promise(resolve=>setImmediate(resolve));
  assert.equal(batches,3);
  assert.match(document.querySelector('#offlineStatus').textContent,/Готово/);
  assert.equal(document.querySelector('#prepareOffline').hidden,true);
});
