import {test} from 'node:test';import assert from 'node:assert/strict';
import {fuseCellText} from '../web/text-fusion.mjs';import {parsePositionedPage} from '../web/parser.mjs';
const item=(text,y=50,x=10,w=180)=>({text,x,y,w,h:10});
const box=[{left:0,top:0,right:300,bottom:100}];
test('restores spaced PDF words and exact field labels without replacing letters',()=>{
 const r=fuseCellText([item('М а тем а тика (Л екци онн ы е занятия)')],[item('Математика (Лекционные ланятив)')],box,10);
 assert.equal(r[0].text,'Математика (Лекционные занятия)');
});
test('restores teacher initials without a hardcoded teacher dictionary',()=>{
 const r=fuseCellText([item('П ахом ова Н.А.')],[item('Пахомова Н.А.')],box,10);assert.equal(r[0].text,'Пахомова Н.А.');assert.equal(r[0].reviewText,undefined);
});
test('room-label damage alone needs no review when the actual number agrees',()=>{
 const r=fuseCellText([item('А у д и т о р и я 322')],[item('Ампитопия 322')],box,10);assert.equal(r[0].text,'Аудитория 322');assert.equal(r[0].reviewText,undefined);
});
test('disagreeing room numbers stay flagged even when one reading was selected',()=>{
 const r=fuseCellText([item('Аудитория 477')],[item('Аудитория 422')],box,10);assert.ok(r[0].reviewText);assert.equal(r[0].roomEvidence.pdf,'477');
});
test('same-looking surnames are not silently merged',()=>{
 const r=fuseCellText([item('Иванова С.А.')],[item('Иванова О.А.')],box,10);assert.equal(r[0].text,'Иванова С.А.');assert.ok(r[0].reviewText);
});
test('a numeric room suffix is not invented from a letter suffix',()=>{
 const r=fuseCellText([item('Аудитория 203э')],[item('Аудитория 2033')],box,10);assert.equal(r[0].text,'Аудитория 203э');assert.ok(r[0].reviewText);
});
test('empty PDF cell retains independent image reading',()=>{
 const r=fuseCellText([],[item('Химия')],box,10);assert.equal(r[0].text,'Химия');
});
