import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readPdfText} from '../web/pdf-text.mjs';

test('PDF text extraction uses getReader when ReadableStream has no async iterator',async()=>{
  const stream=new ReadableStream({start(c){c.enqueue({items:[{str:'Химия'}],styles:{a:{fontFamily:'serif'}},lang:'ru'});c.enqueue({items:[{str:'Знаменатель'}],styles:{b:{fontFamily:'sans-serif'}}});c.close();}});
  Object.defineProperty(stream,Symbol.asyncIterator,{value:undefined});
  const page={streamTextContent:()=>stream,getTextContent(){throw Error('Must not use incompatible PDF.js method');}};
  const content=await readPdfText(page);assert.deepEqual(content.items.map(i=>i.str),['Химия','Знаменатель']);assert.equal(content.lang,'ru');assert.deepEqual(Object.keys(content.styles),['a','b']);assert.equal(stream.locked,false);
});
test('cancelling text extraction cancels the stream, rejects and releases its lock',async()=>{
  let cancelled=false;const stream=new ReadableStream({cancel(reason){assert.ok(reason instanceof Error);cancelled=true;}}),abort=new AbortController();
  const result=readPdfText({streamTextContent:()=>stream},{signal:abort.signal});abort.abort();
  await assert.rejects(result,{name:'AbortError'});assert.equal(cancelled,true);assert.equal(stream.locked,false);
});
test('PDF stream errors are propagated and release their reader lock',async()=>{
  const stream=new ReadableStream({start(c){c.error(Error('Unreadable PDF'));}});await assert.rejects(readPdfText({streamTextContent:()=>stream}),/Unreadable PDF/);assert.equal(stream.locked,false);
});
