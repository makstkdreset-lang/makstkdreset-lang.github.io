import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readPdfText} from '../web/pdf-text.mjs';

test('PDF text extraction uses getReader when ReadableStream has no async iterator',async()=>{
  const stream=new ReadableStream({start(c){c.enqueue({items:[{str:'Химия'}],styles:{a:{fontFamily:'serif'}},lang:'ru'});c.enqueue({items:[{str:'Знаменатель'}],styles:{b:{fontFamily:'sans-serif'}}});c.close();}});
  Object.defineProperty(stream,Symbol.asyncIterator,{value:undefined});
  const page={streamTextContent:()=>stream,getTextContent(){throw Error('Must not use incompatible PDF.js method');}};
  const content=await readPdfText(page);assert.deepEqual(content.items.map(i=>i.str),['Химия','Знаменатель']);assert.equal(content.lang,'ru');assert.deepEqual(Object.keys(content.styles),['a','b']);assert.equal(stream.locked,false);
});
test('cancelling text extraction cancels the stream, rejects and releases its lock',async()=>{
  let cancelled=false;const stream=new ReadableStream({cancel(reason){assert.ok(reason instanceof Error);cancelled=true;}}),abort=new AbortController();
  const result=readPdfText({streamTextContent:()=>stream},{signal:abort.signal});abort.abort();
  await assert.rejects(result,{name:'AbortError'});assert.equal(cancelled,true);assert.equal(stream.locked,false);
});
test('PDF stream errors are propagated and release their reader lock',async()=>{
  const stream=new ReadableStream({start(c){c.error(Error('Unreadable PDF'));}});await assert.rejects(readPdfText({streamTextContent:()=>stream}),/Unreadable PDF/);assert.equal(stream.locked,false);
});

test('damaged PDF text is retried as an image; healthy text avoids OCR',async()=>{
  const {parsePdfPageWithFallback}=await import('../web/recognize.mjs');let scans=0;
  const scan=async()=>{scans++;return 'raster';};
  assert.equal(await parsePdfPageWithFallback(async()=>{throw Error('Unreadable week marks');},scan),'raster');
  assert.equal(await parsePdfPageWithFallback(async()=>null,scan),'raster');
  assert.equal(await parsePdfPageWithFallback(async()=>'text',scan),'text');assert.equal(scans,2);
  await assert.rejects(parsePdfPageWithFallback(async()=>{throw new DOMException('cancel','AbortError');},scan),{name:'AbortError'});assert.equal(scans,2);
  await assert.rejects(parsePdfPageWithFallback(async()=>null,async()=>{throw Error('Image unreadable');}),/Image unreadable/);
});
