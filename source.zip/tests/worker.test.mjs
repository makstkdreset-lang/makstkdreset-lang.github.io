import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync} from 'node:fs';
import worker from '../dist/server/index.js';
function setup(){const db=new DatabaseSync(':memory:');db.exec(readFileSync(new URL('../drizzle/0000_rich_carmella_unuscione.sql',import.meta.url),'utf8'));return {DB:{prepare(sql){return {bind(...args){return {async first(){return db.prepare(sql).get(...args)||null;}};}};}}};}
const schedule=()=>({schemaVersion:1,group:'103',sourceName:'test.pdf',lessons:[{day:0,week:'num',number:1,start:'08:00',end:'09:35',variants:[{subject:'Химия',type:'Лекция',teacher:'',room:'101'}]}]});
function request(method='GET',body,user='owner',origin='https://example.test'){const headers={};if(user)headers['oai-authenticated-user-id']=user;if(body){headers['Content-Type']='application/json';headers.Origin=origin;}return new Request('https://example.test/api/schedule',{method,headers,body:body?JSON.stringify(body):undefined});}
test('API requires trusted signed-in user',async()=>{const response=await worker.fetch(request('GET',null,null),setup());assert.equal(response.status,401);});
test('save/read round trip persists with owner isolation and optimistic revision',async()=>{
  const env=setup();assert.deepEqual(await (await worker.fetch(request(),env)).json(),{schedule:null,revision:0});
  const put=await worker.fetch(request('PUT',{schedule:schedule(),expectedRevision:0}),env);assert.equal(put.status,200);assert.equal((await put.json()).revision,1);
  const read=await (await worker.fetch(request(),env)).json();assert.equal(read.schedule.lessons[0].variants[0].subject,'Химия');assert.equal(read.revision,1);
  assert.equal((await (await worker.fetch(request('GET',null,'other-user'),env)).json()).schedule,null);
  assert.equal((await worker.fetch(request('PUT',{schedule:schedule(),expectedRevision:0}),env)).status,409);
  assert.equal((await (await worker.fetch(request('PUT',{schedule:schedule(),expectedRevision:1}),env)).json()).revision,2);
  assert.equal((await worker.fetch(request('PUT',{schedule:schedule(),expectedRevision:1}),env)).status,409);
});
test('invalid schedules and cross-origin writes never change stored data',async()=>{
  const env=setup();assert.equal((await worker.fetch(request('PUT',{schedule:schedule(),expectedRevision:0},'owner','https://evil.test'),env)).status,403);
  const s=schedule();s.lessons[0].end='07:00';assert.equal((await worker.fetch(request('PUT',{schedule:s,expectedRevision:0}),env)).status,400);
  assert.equal((await (await worker.fetch(request(),env)).json()).revision,0);
});
test('missing database returns recoverable error; root document and static assets route correctly',async()=>{
  assert.equal((await worker.fetch(request(),{})).status,503);
  const root=await worker.fetch(new Request('https://example.test/'),{});assert.match(await root.text(),/Распознать расписание/);
  const asset=await worker.fetch(new Request('https://example.test/app.js'),{ASSETS:{fetch:()=>new Response('asset')}});assert.equal(await asset.text(),'asset');
});
test('legacy dispatch verified-email identity can save and reload; new user-ID header preserves its data',async()=>{
  const env=setup();
  const legacy=(method='GET',body,email='student@example.test',id=null)=>{const r=request(method,body,id);r.headers.set('oai-authenticated-user-email',email);return r;};
  assert.equal((await worker.fetch(legacy(),env)).status,200);
  assert.equal((await worker.fetch(legacy('PUT',{schedule:schedule(),expectedRevision:0}),env)).status,200);
  const read=await (await worker.fetch(legacy(),env)).json();assert.equal(read.revision,1);assert.equal(read.schedule.group,'103');
  assert.equal((await (await worker.fetch(legacy('GET',null,'Student@Example.Test','site-user-id'),env)).json()).revision,1);
  assert.equal((await worker.fetch(legacy('PUT',{schedule:schedule(),expectedRevision:1},'student@example.test','site-user-id'),env)).status,200);
  assert.equal((await (await worker.fetch(legacy(),env)).json()).revision,2);
  assert.equal((await (await worker.fetch(legacy('GET',null,'someone-else@example.test'),env)).json()).schedule,null);
});
test('email supplied in payload or malformed email never grants identity',async()=>{
  const env=setup(),body={schedule:schedule(),expectedRevision:0,email:'student@example.test',userId:'owner'};
  assert.equal((await worker.fetch(request('PUT',body,null),env)).status,401);
  const bad=request('GET',null,null);bad.headers.set('oai-authenticated-user-email','not-an-email');assert.equal((await worker.fetch(bad,env)).status,401);
});
