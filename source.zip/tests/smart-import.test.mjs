import {test} from 'node:test';
import assert from 'node:assert/strict';
import {parsePositionedPage,validateSchedule} from '../web/parser.mjs';
import {readCalendar,currentWeek} from '../web/calendar.mjs';
import {mergePages} from '../web/recognize.mjs';
const item=(text,x,y,w=30,h=10,extra={})=>({text,x,y,w,h,vertical:false,...extra});
function table(){
  const items=[item('Неделя',170,50),item('Понедельник',50,140)];
  for(const [i,y] of [100,140,180,220].entries())items.push(item(i%2?'з':'ч',180,y,8));
  items.push(item('08:00–09:35',100,120,60),item('09:45–11:20',100,200,60));return items;
}
test('wrapped subgroup headings split by their complete labels, not only the first line',()=>{
  const items=table();for(const x of [220,510])items.push(item('Длинное название',x,86,200),item('предмета (Лабораторные занятия)',x,98,210),item('Иванов И.И.',x+20,110,100));
  const s=parsePositionedPage(items);assert.equal(s.lessons[0].variants.length,2);assert.equal(s.lessons[0].variants[0].subject,'Длинное название предмета');
});
test('painted row borders stop text leaking across unequal numerator/denominator rows',()=>{
  const items=table();items.push(item('Химия (Лекционные занятия)',230,110,240),item('Иванов И.И.',260,123,100),item('Аудитория 303к',260,134,110),item('История (Практические занятия)',230,149,260));
  items.find(i=>i.text==='з').y=155;
  // Time is centered in the merged cell; marks can have unequal row heights.
  items.find(i=>i.text==='08:00–09:35').y=123;
  const rules=[80,140,166,200,240].map(p=>({axis:'h',p,start:170,end:750}));
  const s=parsePositionedPage(items,{rules});assert.equal(s.lessons[0].variants[0].room,'303к');assert.equal(s.lessons[1].variants[0].subject,'История');
});
test('OCR repairs room-label lookalikes within a room line and flags uncertain text',()=>{
  const items=table();items.push(item('Химия (Лекционные занятия)',230,90,230),item('Иванов И.И.',260,100,100),item('Ампитопия ЗОЗк.',260,110,120,10,{confidence:42}));
  const s=parsePositionedPage(items,{method:'ocr'});assert.equal(s.lessons[0].variants[0].teacher,'Иванов И.И.');assert.equal(s.lessons[0].variants[0].room,'303к');assert.ok(s.lessons[0].issues.length);assert.equal(s.quality.corrections,2);
});
test('calendar reads an explicit anchor, alternates on Mondays and never guesses a missing date',()=>{
  const c=readCalendar('Расписание учебных занятий с 1 сентября 2026 г. (числитель)');
  assert.deepEqual(c,{anchorDate:'2026-09-01',anchorWeek:'num'});
  for(const [date,expected] of [[6,'num'],[7,'den'],[13,'den'],[14,'num'],[21,'den']])assert.equal(currentWeek(c,new Date(2026,8,date,12)),expected);
  assert.equal(readCalendar('2026 год · числитель'),null);assert.equal(readCalendar('с 31 февраля 2026 г. (числитель)'),null);assert.equal(currentWeek(null),null);
});
test('overlapping lesson times fail validation instead of silently creating two simultaneous pairs',()=>{
  const s={schemaVersion:1,lessons:[{day:0,week:'num',number:1,start:'08:00',end:'09:35',variants:[{subject:'Химия'}]},{day:0,week:'num',number:2,start:'09:00',end:'10:30',variants:[{subject:'История'}]}]};
  assert.throws(()=>validateSchedule(s),/пересекается/);
});
test('day cell borders identify a new day even when its first pair is later than the previous day',()=>{
  const items=table().filter(i=>i.text!=='Понедельник');items.push(item('Понедельник',50,120),item('Вторник',50,200));
  for(const y of [100,140,180,220])items.push(item('Химия (Лекционные занятия)',230,y,240));
  const rules=[80,160,240].map(p=>({axis:'h',p,start:40,end:800}));
  const s=parsePositionedPage(items,{rules});assert.deepEqual(s.lessons.map(l=>l.day),[0,0,1,1]);assert.equal(s.lessons[2].number,2);
});
test('page merge retains global pair numbers when later pages omit the early slot',()=>{
  const lesson=(day,number,start,end)=>({day,week:'num',number,start,end,variants:[{subject:'Химия',type:'Лекция',teacher:'',room:''}]});
  const first={schemaVersion:1,group:'103',lessons:[lesson(0,1,'08:00','09:35'),lesson(0,2,'09:45','11:20')]};
  const next={schemaVersion:1,group:'103',lessons:[lesson(1,1,'09:45','11:20')]};
  const result=mergePages([first,next]);assert.equal(result.lessons.at(-1).number,2);
});
