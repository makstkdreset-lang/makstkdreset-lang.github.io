// Independently transcribed from the supplied, visually inspected PDF. Test
// fixture only: production recognition never imports or matches this content.
const v=(subject,type,teacher='',room='')=>({subject,type,teacher,room});
const math=v('Математика','Лекция','Акулич О.Е.','322');
const russian=v('Русский язык и культура речи','Практика','Терпугова Т.Г.','417');
const geometry=v('Начертательная геометрия','Лекция','Лещенко Г.П.','426');
const informatics=[v('Информатика','Лабораторная','Пахомова Н.А.','427'),v('Информатика','Лабораторная','Витт А.М.','427')];
const history=v('История России','Практика','Палецких Н.П.','413');
const historyLecture=v('История России','Лекция','Палецких Н.П.');
const sport=v('Элективные курсы по физической культуре и спорту','Практика','Истамгулова Р.Р.');
const geometryLab=v('Начертательная геометрия','Лабораторная','Торбеев И.Г., Лещенко Г.П.','303к');
const statehood=v('Основы российской государственности','Практика','Погуляева С.А.','419а');
const mechanics=[v('Прикладная механика','Лабораторная','Трояновская И.П.','431'),v('Прикладная механика','Лабораторная','Гребенщикова О.А.','433')];
const mathPractice=v('Математика','Практика','Акулич О.Е.','322');
const training=v('Учебная ознакомительная практика','Практика','Кривошеева Е.И.','112э');
const rows=[
  [0,1,math,math],
  [0,2,v('Химия','Практика','Батовская Е.К.','319'),v('Инженерная экология','Практика','Медведева Л.М.','208')],
  [0,3,russian,russian],
  [0,4,v('Химия','Лекция','Батовская Е.К.','319'),v('Прикладная механика','Лекция','Трояновская И.П.','440')],
  [0,5,v('Введение в профессиональную деятельность','Лекция','Иванова С.А.','203э'),null],
  [1,2,geometry,geometry],[1,3,informatics,informatics],[1,4,history,history],[1,5,historyLecture,historyLecture],
  [2,1,sport,sport],[2,2,geometryLab,geometryLab],[2,3,statehood,statehood],[2,4,null,null],
  [2,5,v('Русский язык и культура речи','Лекция'),v('Физическая культура и спорт','Лекция','Прохоров В.В.')],
  [3,1,sport,sport],
  [3,2,v('Информатика','Лекция','Пахомова Н.А.','426'),v('Инженерная экология','Лекция','Медведева Л.М.','503')],
  [3,3,mechanics,mechanics],[3,4,mathPractice,mathPractice],[3,5,v('Основы российской государственности','Лекция'),null],
  [4,1,v('Основы производства продукции растениеводства','Лабораторная','Зыбалов В.С.','208'),null],
  [4,2,training,training],[4,3,training,training],[4,4,training,training]
];
const times=[['08:00','09:35'],['09:45','11:20'],['11:50','13:25'],['13:35','15:10'],['15:25','17:00']];
export const expected=rows.flatMap(([day,number,num,den])=>[['num',num],['den',den]].filter(([,value])=>value).map(([week,value])=>({day,week,number,start:times[number-1][0],end:times[number-1][1],variants:Array.isArray(value)?value:[value]})));
export const comparable=schedule=>schedule.lessons.map(({day,week,number,start,end,variants})=>({day,week,number,start,end,variants}));
