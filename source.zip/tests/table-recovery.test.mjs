import {test} from 'node:test';import assert from 'node:assert/strict';
import {recoverRuledTable} from '../web/table-recovery.mjs';import {validateSchedule} from '../web/parser.mjs';
function fixture(){
 const item=(text,x,y,w=20,h=8)=>({text,x,y,w,h,vertical:false});
 const image={width:600,height:500,data:new Uint8ClampedArray(600*500*4).fill(255)};
 for(let y=60;y<=396;y+=28)for(let x=100;x<560;x++){const k=(y*600+x)*4;image.data[k]=image.data[k+1]=image.data[k+2]=0;}
 const hints=[item('Недели',174,44,38),item('Понедельник',50,116),item('Вторник',50,228),item('Среда',50,340)];
 const ocr=[];for(let i=0;i<12;i++){if(i>0)hints.push(item(i%2?'3':'ч',189,74+i*28,8));ocr.push(item('Химия (Лекционные занятия)',240,74+i*28,310));}
 for(let i=0;i<6;i++)if(i!==0)hints.push(item(i%2?'10:00 - 11:30':'08:00 - 09:30',100,88+i*56,72));
 return {image,hints,ocr};
}
test('ruled recovery keeps all rows, reconstructs missing marks and marks the draft for review',async()=>{
 const {image,hints,ocr}=fixture();const r=await recoverRuledTable(image,ocr,hints);assert.deepEqual(r.counts,{num:6,den:6});assert.equal(r.lessons[0].start,'08:00');assert.ok(r.lessons.every(l=>l.issues.length));validateSchedule(r);
});
test('recovery refuses contradictory week parity or missing grid boundaries',async()=>{
 const {image,hints,ocr}=fixture();const conflicting=hints.map(i=>({...i,text:i.text==='3'?'ч':i.text}));await assert.rejects(recoverRuledTable(image,ocr,conflicting),/Порядок Ч\/З/);
 image.data.fill(255);await assert.rejects(recoverRuledTable(image,ocr,hints),/Границы/);
});
