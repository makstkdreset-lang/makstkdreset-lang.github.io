import {test} from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const origin='https://schedule.test';
const source=fs.readFileSync(new URL('../dist/client/sw.js',import.meta.url),'utf8');
const root=fileURLToPath(new URL('../dist/client/',import.meta.url));
function harness(){
  const handlers={},stores=new Map(),requests=[];let online=true,login=false,missing='';
  const key=input=>typeof input==='string'?input:input.url;
  const caches={async open(name){if(!stores.has(name))stores.set(name,new Map());const map=stores.get(name);return {async match(input){return map.get(key(input))?.clone();},async put(input,response){map.set(key(input),response.clone());}};},async keys(){return [...stores.keys()];},async delete(name){return stores.delete(name);}};
  const self={location:{origin},clients:{claim:async()=>{}},skipWaiting:async()=>{},addEventListener:(type,handler)=>handlers[type]=handler};
  const fetch=async request=>{
    requests.push(request);
    if(!online)throw Error('Offline');
    const url=new URL(key(request));
    if(login&&url.pathname==='/')return new Response('<html>Login</html>',{headers:{'Content-Type':'text/html'}});
    if(url.pathname===missing)return new Response('Not found',{status:404,headers:{'Content-Type':'text/html'}});
    const filename=path.join(root,url.pathname==='/'?'index.html':url.pathname);
    const bytes=fs.readFileSync(filename);
    const type=url.pathname==='/'||url.pathname==='/index.html'?'text/html':filename.endsWith('.mjs')||filename.endsWith('.js')?'text/javascript':filename.endsWith('.svg')?'image/svg+xml':filename.endsWith('.webmanifest')?'application/manifest+json':'application/octet-stream';
    return new Response(bytes,{headers:{'Content-Type':type}});
  };
  const context=vm.createContext({self,caches,fetch,URL,Request,Response,AbortController,setTimeout,clearTimeout});vm.runInContext(source,context);
  async function event(type,args={}){let work=Promise.resolve(),result;handlers[type]({...args,waitUntil:p=>work=p,respondWith:p=>result=p});const response=await result;await work;return response;}
  async function message(type){const messages=[];await event('message',{data:{type},source:{url:origin+'/'},ports:[{postMessage:m=>messages.push(m)}]});return messages.at(-1);}
  const navigation=()=>{const request=new Request(origin+'/');Object.defineProperty(request,'mode',{value:'navigate'});return event('fetch',{request});};
  return {event,message,navigation,context,requests,stores,set(options){if('online'in options)online=options.online;if('login'in options)login=options.login;if('missing'in options)missing=options.missing;}};
}
test('static shell and all recognition resources automatically prepare, then launch offline',async()=>{
  const h=harness();await h.event('install');await h.event('activate');
  let s=(await h.message('STATUS')).status;assert.equal(s.coreReady,true);
  for(let i=0;i<100&&!s.recognitionReady;i++){const result=await h.message('PREPARE');assert.equal(result.type,'done');s=result.status;}
  assert.equal(s.recognitionReady,true);assert.equal(s.cachedBytes,s.totalBytes);
  h.set({online:false});assert.match(await (await h.navigation()).text(),/moi-pary-static/);
  for(const url of ['/app.js?v=pwa-1','/vendor/pdf/pdf.mjs','/vendor/tesseract/worker.min.js','/vendor/lang/rus.traineddata.gz']){
    const request=new Request(origin+url);const response=await h.event('fetch',{request});assert.equal(response.status,200,url);
  }
  assert.ok(h.requests.every(request=>!new URL(request.url).pathname.startsWith('/api/')));
});
test('a login page is rejected and cannot be cached as the app shell',async()=>{
  const h=harness();h.set({login:true});await h.event('install');const result=await h.message('PREPARE');assert.equal(result.type,'error');assert.match(result.message,/сохранить \/:/);
  assert.equal((await h.message('STATUS')).status.coreReady,false);
  h.set({login:false});assert.equal((await h.message('PREPARE')).type,'done');
});
test('a missing OCR asset reports its path and preparation resumes',async()=>{
  const h=harness();await h.event('install');h.set({missing:'/vendor/pdf/pdf.mjs'});let error;
  for(let i=0;i<100;i++){const result=await h.message('PREPARE');if(result.type==='error'){error=result;break;}}
  assert.match(error.message,/pdf.mjs/);
  h.set({missing:''});let result;for(let i=0;i<100;i++){result=await h.message('PREPARE');if(result.status?.recognitionReady)break;}
  assert.equal(result.status.recognitionReady,true);
});
test('build contains every offline resource and iPhone icons',()=>{
  const h=harness(),resources=vm.runInContext('RESOURCES',h.context);assert.ok(resources.length>200);
  for(const item of resources)assert.equal(fs.statSync(path.join(root,item.path)).size,item.bytes);
  const manifest=JSON.parse(fs.readFileSync(path.join(root,'manifest.webmanifest'),'utf8'));
  assert.equal(manifest.display,'standalone');assert.equal(manifest.start_url,'/#today');
  for(const size of [180,192,512]){const png=fs.readFileSync(path.join(root,`icons/icon-${size}.png`));assert.equal(png.readUInt32BE(16),size);}
});
