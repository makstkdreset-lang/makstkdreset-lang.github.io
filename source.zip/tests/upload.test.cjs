const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const {parseHTML}=require('linkedom');
const html=fs.readFileSync(require('node:path').join(__dirname,'../dist/index.html'),'utf8');
const key='moi-pary.ui.v5';
const fixture=()=>({schemaVersion:1,group:'103',sourceName:'schedule.pdf',method:'pdf-text',warnings:[],lessons:[
  {day:0,week:'num',number:1,start:'08:00',end:'09:35',variants:[{subject:'Химия',type:'Лекция',teacher:'Иванов И.И.',room:'101'}]},
  {day:0,week:'den',number:1,start:'08:00',end:'09:35',variants:[{subject:'Экология',type:'Практика',teacher:'',room:''}]}
]});
const file=(name='schedule.pdf',size=47837,type='application/pdf')=>({name,size,type,slice(){throw Error('Selecting a file must not read bytes');},arrayBuffer(){throw Error('Selecting a file must not read bytes');}});
async function boot({storage=new Map(),localStorage=new Map(),hash='',denied=false,recognize,now=()=>new Date(2026,8,14,9)}={}){
  const {document,window:domWindow}=parseHTML(html),events={},tasks=new Map();let nextTask=0;
  const location={hash};
  const window={location,history:{replaceState(_a,_b,h){location.hash=h;}},sessionStorage:{getItem(k){if(denied)throw Error('denied');return storage.get(k);},setItem(k,v){if(denied)throw Error('denied');storage.set(k,v);}},localStorage:{getItem(k){if(denied)throw Error('denied');return localStorage.get(k);},setItem(k,v){if(denied)throw Error('denied');localStorage.set(k,v);}},navigator:{},confirm:()=>true,addEventListener:(name,fn)=>events[name]=fn};
  const {startApp}=await import('../web/app.mjs');
  const app=startApp({document,window,recognize:recognize||(async()=>fixture()),now,scheduleTask:fn=>{tasks.set(++nextTask,fn);return nextTask;},cancelTask:id=>tasks.delete(id)});
  await app.ready;
  const q=s=>document.querySelector(s),event=(selector,type)=>q(selector).dispatchEvent(new domWindow.Event(type,{bubbles:true}));
  function choose(f,id='gallery'){event('#'+id,'click');q('#'+id).files=f?[f]:[];event('#'+id,'change');}
  function confirm(){q('#confirmed').checked=true;event('#confirmed','change');}
  async function runQueued(){for(const [id,fn] of tasks){tasks.delete(id);fn();}await new Promise(resolve=>setImmediate(resolve));}
  return {app,q,event,choose,confirm,storage,localStorage,location,events,runQueued,visibility:()=>document.dispatchEvent(new domWindow.Event('visibilitychange'))};
}
test('teacher buttons open confirmed full names in Today and Week while offline',async()=>{
  const {expected}=await import('./fixtures/group103.mjs');
  const s={...fixture(),lessons:expected,calendar:{anchorDate:'2026-09-01',anchorWeek:'num'}};
  for(const [date,shortName,fullName,curator] of [
    [21,'Трояновская И.П.','Трояновская Ирина Павловна',false],
    [23,'Истамгулова Р.Р.','Истамгулова Ринета Ринатовна',false],
    [25,'Кривошеева Е.И.','Кривошеева Елена Ивановна',true]
  ]){
    const localStorage=new Map([['moi-pary.schedule.v1',JSON.stringify(s)]]);
    const t=await boot({localStorage,now:()=>new Date(2026,8,date,12),fetch:async()=>{throw Error('Offline');}});
    for(const container of ['#todayLessons','#lessons']){
      if(container==='#lessons')t.event('[data-tab="week"]','click');
      t.event(`${container} [data-teacher="${shortName}"] span`,'click');
      assert.equal(t.q('#teacherDialog').hasAttribute('open'),true);
      assert.equal(t.q('#teacherName').textContent,fullName);
      assert.equal(t.q('#teacherCurator').hidden,!curator);
      assert.equal(t.q('#teacherMissingName').hidden,true);
      assert.ok(t.q('#teacherSubject').textContent);
      t.event('#closeTeacher','click');
      assert.equal(t.q('#teacherDialog').hasAttribute('open'),false);
      assert.equal(t.q('body').classList.contains('teacher-dialog-open'),false);
    }
  }
});

test('multiple teachers have separate cards, known names open full profiles, and missing teachers have no button',async()=>{
  const s=fixture();s.calendar={anchorDate:'2026-09-14',anchorWeek:'num'};
  s.lessons[0].variants[0].teacher='Торбеев И.Г., Лещенко Г.П.,';
  const t=await boot({localStorage:new Map([['moi-pary.schedule.v1',JSON.stringify(s)]])});
  assert.equal(t.q('#todayLessons').querySelectorAll('[data-teacher]').length,2);
  t.event('#todayLessons [data-teacher="Лещенко Г.П."]','click');
  assert.equal(t.q('#teacherName').textContent,'Лещенко Галина Павловна');assert.equal(t.q('#teacherMissingName').hidden,true);
  t.event('#teacherDialog','cancel');assert.equal(t.q('#teacherDialog').hasAttribute('open'),false);
  t.event('[data-week="den"]','click');assert.equal(t.q('#lessons [data-teacher]'),null);
});

test('teacher matching tolerates spacing but never guesses another person or another groups curator',async()=>{
  const {teacherProfile}=await import('../web/teachers.mjs');
  for(const [shortName,fullName] of [
    ['Акулич О.Е.','Акулич Ольга Евгеньевна'],
    ['Батовская Е.К.','Батовская Екатерина Константиновна'],
    ['Витт А.М.','Витт Анастасия Михайловна'],
    ['Гребенщикова О.А.','Гребенщикова Ольга Александровна'],
    ['Зыбалов В.С.','Зыбалов Владимир Степанович'],
    ['Иванова С.А.','Иванова Светлана Александровна'],
    ['Истамгулова Р.Р.','Истамгулова Ринета Ринатовна'],
    ['Кривошеева Е.И.','Кривошеева Елена Ивановна'],
    ['Лещенко Г.П.','Лещенко Галина Павловна'],
    ['Медведева Л.М.','Медведева Людмила Михайловна'],
    ['Палецких Н.П.','Палецких Надежда Петровна'],
    ['Пахомова Н.А.','Пахомова Наталья Алексеевна'],
    ['Погуляева С.А.','Погуляева Светлана Алексеевна'],
    ['Терпугова Т.Г.','Терпугова Татьяна Генриховна'],
    ['Трояновская И.П.','Трояновская Ирина Павловна']
  ]){
    assert.equal(teacherProfile(shortName,'103').name,fullName);
    assert.equal(teacherProfile(shortName,'103').known,true);
  }
  assert.equal(teacherProfile('Трояновская И. П.','103').name,'Трояновская Ирина Павловна');
  assert.equal(teacherProfile('Трояновская А.П.','103').known,false);
  assert.equal(teacherProfile('Кривошеева Е.И.','108').isCurator,false);
  assert.equal(teacherProfile('Кривошеева Елена Ивановна','103').isCurator,true);
  const s=fixture();s.calendar={anchorDate:'2026-09-14',anchorWeek:'num'};
  const name='<img src=x onerror=alert(1)>';s.lessons[0].variants[0].teacher=name;
  const t=await boot({localStorage:new Map([['moi-pary.schedule.v1',JSON.stringify(s)]])});
  assert.equal(t.q('#todayLessons img'),null);t.event('#todayLessons [data-teacher]','click');
  assert.equal(t.q('#teacherName').textContent,name);assert.equal(t.q('#teacherDialog img'),null);
  t.event('#teacherDialog','click');assert.equal(t.q('#teacherDialog').hasAttribute('open'),false);
});

test('picker callback does not decode before closing; recognition is deferred; small PDF size is in KB',async()=>{
  let calls=0;const t=await boot({recognize:async()=>{calls++;return fixture();}});
  for(const [f,id] of [[file('a.jpg',1000,'image/jpeg'),'gallery'],[file('b.jpg',1000,'image/jpeg'),'camera'],[file('a.heic',12000,'image/heic'),'gallery'],[file(),'gallery']]){
    t.choose(f,id);assert.equal(t.q('#fileName').textContent,f.name);assert.equal(t.location.hash,'#settings');assert.equal(t.q('#recognize').hidden,false);assert.equal(t.q('#'+id).value,'');
  }
  assert.equal(calls,0);assert.match(t.q('#fileHint').textContent,/47 КБ/);assert.equal(t.q('#review').hidden,true);
});
test('reload during picker returns to Today, preserves week and day, and never claims lost File is present',async()=>{
  const t=await boot();t.event('[data-week="den"]','click');t.event('[data-day="4"]','click');t.choose(file('private.pdf'));t.event('#camera','click');
  assert.equal(t.storage.get(key).includes('private.pdf'),false);
  const next=await boot({storage:t.storage,localStorage:t.localStorage});assert.equal(next.location.hash,'#today');assert.equal(next.app.getState().week,'den');assert.equal(next.app.getState().day,4);assert.equal(next.q('#recognize').hidden,true);assert.match(next.q('#fileStatus').textContent,/выбрать заново/);
});
test('denied or invalid session storage does not break upload',async()=>{
  for(const opts of [{denied:true},{storage:new Map([[key,'{']])},{storage:new Map([[key,'{"day":99,"week":"bad"}']])}]){
    const t=await boot(opts);t.choose(file());assert.equal(t.q('#recognize').hidden,false);
  }
});
test('invalid, empty and oversized files preserve previous valid selection; cancel preserves it',async()=>{
  const t=await boot(),valid=file();t.choose(valid);
  for(const f of [file('empty.pdf',0),file('large.pdf',26*1024*1024),file('a.exe',40,'application/octet-stream')]){t.choose(f);assert.equal(t.q('#fileStatus').dataset.tone,'error');assert.equal(t.app.getState().file,valid);}
  t.event('#gallery','cancel');assert.match(t.q('#fileStatus').textContent,/Предыдущий файл/);
});
test('unambiguous result saves in one click, never automatically, and populates both weeks',async()=>{
  const t=await boot();
  t.choose(file());await t.app.doRecognize();assert.equal(t.q('#review').hidden,false);assert.match(t.q('#resultSummary').textContent,/Ч: 1 пара · З: 1 пара/);assert.equal(t.q('#save').disabled,false);assert.equal(t.localStorage.has('moi-pary.schedule.v1'),false);
  assert.equal(t.q('#confirmation').hidden,true);await t.app.saveDraft();assert.equal(t.location.hash,'#today');t.event('[data-tab="week"]','click');assert.match(t.q('#lessons').textContent,/Химия/);
  t.event('[data-week="den"]','click');assert.match(t.q('#lessons').textContent,/Экология/);assert.equal(t.q('#review').hidden,true);assert.equal(t.app.getState().draft,null);
});
test('edits reset confirmation, preserve draft on reload and escape arbitrary recognized text',async()=>{
  const t=await boot({recognize:async()=>{const s=fixture();s.lessons[0].variants[0].subject='<img src=x onerror=alert(1)>';return s;}});
  t.choose(file());await t.app.doRecognize();assert.equal(t.q('#reviewList img'),null);assert.match(t.q('#reviewList').textContent,/<img src=x/);t.confirm();
  const input=t.q('[data-index="0"][data-field="subject"]');input.value='Исправленный предмет';t.event('[data-index="0"][data-field="subject"]','change');assert.equal(t.q('#confirmed').checked,false);
  const next=await boot({storage:t.storage});assert.equal(next.q('#review').hidden,false);assert.match(next.q('#reviewList').textContent,/Исправленный предмет/);assert.equal(next.q('#save').disabled,false);
});
test('saved timetable persists after a new launch without network',async()=>{
  const t=await boot();t.choose(file());await t.app.doRecognize();await t.app.saveDraft();
  const next=await boot({localStorage:t.localStorage});assert.equal(next.app.getState().draft,null);assert.match(next.q('#lessons').textContent,/Химия/);assert.ok(next.localStorage.get('moi-pary.schedule.v1'));
});
test('failed or cancelled recognition leaves old draft and saved schedule intact',async()=>{
  let fail=false;const t=await boot({recognize:async()=>{if(fail)throw Error('Не читаются метки Ч/З');return fixture();}});
  t.choose(file());await t.app.doRecognize();const draft=t.app.getState().draft;fail=true;await t.app.doRecognize();assert.equal(t.app.getState().draft,draft);assert.match(t.q('#fileStatus').textContent,/Не читаются/);assert.equal(t.q('#recognize').disabled,false);
});
test('no account or server login is needed to save a timetable',async()=>{
  const t=await boot();t.choose(file());await t.app.doRecognize();assert.equal(t.q('#signIn'),null);assert.equal(t.q('#save').disabled,false);await t.app.saveDraft();assert.match(t.q('#lessons').textContent,/Химия/);assert.ok(t.localStorage.get('moi-pary.schedule.v1'));
});
test('obsolete file-picker warning and copy-link panel are removed',async()=>{
  const t=await boot();assert.equal(t.q('.browser-help'),null);assert.equal(t.q('#copyLink'),null);assert.equal(t.q('#siteLink'),null);
});
test('cancel unblocks UI even when the recognition engine has not resolved; late result cannot replace draft',async()=>{
  let complete;const t=await boot({recognize:()=>new Promise(resolve=>complete=resolve)});t.choose(file());const pending=t.app.doRecognize();assert.equal(t.q('#cancel').hidden,false);t.event('#cancel','click');await pending;assert.equal(t.app.getState().busy,false);assert.match(t.q('#fileStatus').textContent,/отменено/);complete(fixture());await Promise.resolve();assert.equal(t.app.getState().draft,null);
});
test('unhandled library errors show a recoverable Russian message, not a JavaScript dump',async()=>{
  const t=await boot({recognize:async()=>{throw new TypeError("undefined is not a function (near value of readableStream)");}});t.choose(file());await t.app.doRecognize();assert.match(t.q('#fileStatus').textContent,/Не удалось прочитать файл/);assert.doesNotMatch(t.q('#fileStatus').textContent,/undefined|readableStream/);assert.equal(t.q('#recognize').disabled,false);
});
test('valid selection automatically starts after picker closes; cancellation prevents queued work',async()=>{
  let calls=0;const t=await boot({recognize:async()=>{calls++;return fixture();}});
  t.choose(file());assert.equal(calls,0);assert.equal(t.q('#cancel').hidden,false);await t.runQueued();assert.equal(calls,1);assert.ok(t.app.getState().draft);
  t.choose(file());t.event('#cancel','click');await t.runQueued();assert.equal(calls,1);assert.equal(t.app.getState().busy,false);
});
test('uncertain rows are filtered and require a check; marking a row reviewed removes its warning',async()=>{
  const t=await boot({recognize:async()=>{const s=fixture();s.lessons[1].issues=['Нечёткий текст'];return s;}});
  t.choose(file());await t.runQueued();assert.equal(t.q('#issuesOnly').checked,true);assert.match(t.q('#reviewList').textContent,/Экология/);assert.doesNotMatch(t.q('#reviewList').textContent,/Химия/);assert.equal(t.q('#save').disabled,true);
  t.event('[data-checked="1"]','click');assert.equal(t.q('#save').disabled,false);assert.equal(t.q('#confirmation').hidden,true);
});
test('today and current week follow the document anchor; manual week viewing stays available',async()=>{
  const s=fixture();s.calendar={anchorDate:'2026-09-01',anchorWeek:'num'};
  const t=await boot({now:()=>new Date(2026,8,7,12),localStorage:new Map([['moi-pary.schedule.v1',JSON.stringify(s)]])});
  assert.equal(t.app.getState().week,'den');assert.equal(t.app.getState().day,0);assert.match(t.q('#calendarStatus').textContent,/сегодня знаменатель/i);
  t.event('[data-week="num"]','click');assert.equal(t.app.getState().week,'num');t.event('#weekToday','click');assert.equal(t.app.getState().week,'den');
});
test('the actual schedule opens on today and keeps the empty fourth pair visible on Wednesday',async()=>{
  const {expected}=await import('./fixtures/group103.mjs');
  const s={...fixture(),lessons:expected,calendar:{anchorDate:'2026-09-01',anchorWeek:'num'}};
  const t=await boot({now:()=>new Date(2026,8,16,12),localStorage:new Map([['moi-pary.schedule.v1',JSON.stringify(s)]])});
  assert.equal(t.app.getState().day,2);assert.match(t.q('#dayTitle').textContent,/Среда/);assert.match(t.q('#lessons').textContent,/4-я пара · окно/);assert.match(t.q('#lessons').textContent,/13:35–15:10/);assert.equal(t.q('#count').textContent,'22');
});
test('offline timetable remains readable and a new schedule saves locally without a server write',async()=>{
  const localStorage=new Map([['moi-pary.schedule.v1',JSON.stringify(fixture())]]);
  const t=await boot({localStorage});
  assert.equal(t.q('#groupLabel').textContent,'Группа 103');assert.match(t.q('#lessons').textContent,/Химия/);
  t.choose(file());await t.app.doRecognize();assert.ok(t.app.getState().draft);assert.equal(t.q('#save').disabled,false);await t.app.saveDraft();assert.ok(t.localStorage.get('moi-pary.schedule.v1'));
});

test('the settings anchor persists locally and selects todays day and numerator automatically',async()=>{
  const localStorage=new Map([['moi-pary.schedule.v1',JSON.stringify(fixture())]]);
  const t=await boot({localStorage,now:()=>new Date(2026,8,21,12),fetch:async()=>Response.json({error:'Войди'},{status:401})});
  t.q('#anchorDate').value='2026-09-01';t.q('#anchorWeek option[value="num"]').selected=true;t.q('#anchorWeek option[value="den"]').selected=false;t.event('#saveCalendar','click');await new Promise(resolve=>setImmediate(resolve));
  assert.equal(t.app.getState().week,'den');assert.equal(t.app.getState().day,0);assert.match(t.q('#calendarStatus').textContent,/сегодня знаменатель/i);assert.equal(JSON.parse(localStorage.get('moi-pary.schedule.v1')).calendar.anchorDate,'2026-09-01');
});

test('today uses the automatic week and never offers a manual numerator switch',async()=>{
  const s=fixture();s.calendar={anchorDate:'2026-09-01',anchorWeek:'num'};
  const t=await boot({now:()=>new Date(2026,8,21,9),localStorage:new Map([['moi-pary.schedule.v1',JSON.stringify(s)]])});
  assert.equal(t.location.hash,'#today');assert.equal(t.q('#today').classList.contains('active'),true);assert.equal(t.q('#todayStatus').textContent,'');assert.match(t.q('#todayWeek').textContent,/Знаменатель/);assert.equal(t.q('#todayGroup').textContent,'Группа 103');assert.equal(t.q('#today [data-week]'),null);
});

test('Today switches to tomorrow at the last lesson end and refreshes on return',async()=>{
  const s=fixture();s.calendar={anchorDate:'2026-09-14',anchorWeek:'num'};
  s.lessons.push({day:1,week:'num',number:1,start:'08:00',end:'09:35',variants:[{subject:'Физика',type:'Лекция',teacher:'',room:'102'}]});
  let time=new Date(2026,8,14,9,34);
  const t=await boot({now:()=>time,localStorage:new Map([['moi-pary.schedule.v1',JSON.stringify(s)]])});
  assert.match(t.q('#todayTitle').textContent,/Понедельник · 14 сентября/);
  time=new Date(2026,8,14,9,35);t.visibility();
  assert.match(t.q('#todayTitle').textContent,/Вторник · 15 сентября/);
  assert.match(t.q('#todayLessons').textContent,/Физика/);
  assert.match(t.q('#todayStatus').textContent,/Пары на сегодня закончились/);
});

test('after Friday lessons a five-day timetable shows Monday and its next week type',async()=>{
  const s=fixture();s.calendar={anchorDate:'2026-09-14',anchorWeek:'num'};
  s.lessons.push({day:4,week:'num',number:3,start:'14:00',end:'15:10',variants:[{subject:'История',type:'Лекция',teacher:'',room:'102'}]});
  const localStorage=new Map([['moi-pary.schedule.v1',JSON.stringify(s)],['moi-pary.preferences.v1',JSON.stringify({studyDays:5})]]);
  const t=await boot({localStorage,now:()=>new Date(2026,8,18,15,11)});
  assert.match(t.q('#todayTitle').textContent,/Понедельник · 21 сентября/);
  assert.match(t.q('#todayWeek').textContent,/Знаменатель/);
  assert.match(t.q('#todayLessons').textContent,/Экология/);
});

test('group can be changed in settings and is reflected in the schedule',async()=>{
  const localStorage=new Map([['moi-pary.schedule.v1',JSON.stringify(fixture())]]);
  const t=await boot({localStorage,fetch:async()=>Response.json({error:'Войди'},{status:401})});
  assert.equal(t.q('#savedGroup').value,'103');t.q('#savedGroup').value='108';t.event('#saveGroup','click');await new Promise(resolve=>setImmediate(resolve));
  assert.equal(t.q('#todayGroup').textContent,'Группа 108');assert.equal(JSON.parse(localStorage.get('moi-pary.schedule.v1')).group,'108');assert.equal(JSON.parse(localStorage.get('moi-pary.preferences.v1')).group,'108');
});

test('V2.0 uses one line-icon style and keeps Today in the middle',async()=>{
  const t=await boot();const tabs=[...t.q('.nav').querySelectorAll('[data-tab]')];assert.equal(t.q('title').textContent,'Мои пары V2.0');assert.equal(tabs.length,3);assert.deepEqual(tabs.map(el=>el.dataset.tab),['week','today','settings']);assert.equal(t.q('.nav').querySelectorAll('svg').length,3);assert.equal(t.q('.nav').querySelectorAll('.nav-icon').length,0);
});

test('five-day and six-day settings hide Sunday and show the next Monday on a day off',async()=>{
  const s=fixture();s.calendar={anchorDate:'2026-09-01',anchorWeek:'num'};
  const localStorage=new Map([['moi-pary.schedule.v1',JSON.stringify(s)]]);
  const t=await boot({localStorage,now:()=>new Date(2026,8,20,12),fetch:async()=>Response.json({error:'Войди'},{status:401})});
  assert.equal(t.q('#days').children.length,6);assert.doesNotMatch(t.q('#days').textContent,/ВС/);assert.match(t.q('#todayTitle').textContent,/Понедельник · 21 сентября/);assert.match(t.q('#todayStatus').textContent,/Сегодня выходной/);assert.match(t.q('#todayWeek').textContent,/Знаменатель/);assert.match(t.q('#todayLessons').textContent,/Экология/);
  t.event('[data-study-days="5"]','click');assert.equal(t.q('#days').children.length,5);assert.equal(t.app.getState().studyDays,5);assert.match(t.q('#todayTitle').textContent,/Понедельник/);assert.equal(JSON.parse(localStorage.get('moi-pary.preferences.v1')).studyDays,5);
});

test('Saturday also advances to Monday when five-day mode is enabled',async()=>{
  const s=fixture();s.calendar={anchorDate:'2026-09-01',anchorWeek:'num'};
  const localStorage=new Map([['moi-pary.schedule.v1',JSON.stringify(s)],['moi-pary.preferences.v1',JSON.stringify({studyDays:5})]]);
  const t=await boot({localStorage,now:()=>new Date(2026,8,19,12),fetch:async()=>Response.json({error:'Войди'},{status:401})});
  assert.match(t.q('#todayTitle').textContent,/Понедельник · 21 сентября/);assert.match(t.q('#todayStatus').textContent,/Сегодня выходной/);assert.match(t.q('#todayLessons').textContent,/Экология/);
});

test('every fresh launch opens Today even if the previous screen or URL was Week',async()=>{
  const storage=new Map([[key,JSON.stringify({tab:'week',week:'den',day:3,viewDate:'2026-09-14'})]]);
  const t=await boot({storage,hash:'#week'});assert.equal(t.location.hash,'#today');assert.equal(t.q('#today').classList.contains('active'),true);assert.equal(t.q('[data-tab="today"]').classList.contains('active'),true);
});
